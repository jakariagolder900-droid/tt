# OmniCalc Extreme Performance

OmniCalc Extreme Performance is a next-generation scientific computing engine, 2D calculus graphing studio, 64-bit programmer calculator, multi-unit physics converter, and hardware stress benchmark suite.

## Core Features & Engines

1. **Scientific & High-Precision Math Engine**
   - Shunting-Yard RPN evaluator supporting arbitrary expressions, nested parentheses, and implicit multiplication.
   - Comprehensive trigonometric and hyperbolic functions (`sin`, `cos`, `tan`, `asin`, `acos`, `atan`, `sinh`, `cosh`, `tanh`).
   - Logarithms and exponentials (`ln`, `log10`, `log2`, `eˣ`, `10ˣ`, `xʸ`, `√x`, `∛x`).
   - Combinatorics & number theory (`n!`, `nCr`, `nPr`, `gcd`, `lcm`, `mod`).
   - Fundamental constants bank: $\pi$, $e$, $\phi$ (Golden Ratio), $c$ (Speed of Light), $h$ (Planck), $G$ (Gravitational), $k_B$ (Boltzmann), $N_A$ (Avogadro).
   - Display modes: Standard decimal, Scientific notation, Engineering notation, Exact/approximate fraction display.
   - Angle modes: Degrees (DEG), Radians (RAD), Gradians (GRAD).
   - Full calculation tape history with export, search, and replay.

2. **Extreme Hardware Benchmark Suite**
   - **Monte Carlo $\pi$ Simulation**: Multi-million stochastic sample compute test.
   - **Dense Float64 GEMM**: Cache-stressed matrix multiplication testing peak double-precision GFLOPS.
   - **Sieve of Eratosthenes**: Uint8Array prime generator up to 3,000,000 measuring memory throughput and branch prediction.
   - **Mandelbrot Escape Iteration**: Multi-iteration complex plane escape throughput test.
   - **Transcendental Pipeline**: Trigonometric and radical stress test.
   - Real-time performance score, hardware tier grading, and exportable scorecard.

3. **2D Graphing & Calculus Studio**
   - Multi-function simultaneous plotting: $f(x)$, $g(x)$, $h(x)$.
   - Real-time smooth pan and zoom with high-DPI canvas rendering.
   - Trace crosshair: displays exact coordinates, tangent slope $f'(x)$.
   - Definite numerical integration tool $\int_a^b f(x) dx$ with visual area shading.
   - Preset library: damped oscillations, polynomial roots, beat wave interference, Gaussian bell curves.

4. **Programmer 64-Bit Suite**
   - Word size modes: QWORD (64-bit), DWORD (32-bit), WORD (16-bit), BYTE (8-bit).
   - Signed (Two's complement) and Unsigned modes.
   - Synchronized simultaneous view: HEX, DEC, OCT, BIN.
   - Interactive 64-bit bitboard: click any bit to toggle in real time.
   - Bitwise logic gates: `AND`, `OR`, `XOR`, `NOT`, `NAND`, `NOR`, `XNOR`.
   - Shifts and rotations: `LSH`, `RSH`, `ASR`, `ROL`, `ROR`.
   - ASCII / UTF-8 byte preview.

5. **Omni Unit Converter**
   - 9 categories: Length, Mass, Temperature, Speed, Digital Storage, Energy, Pressure, Area, Volume.
   - Real-time multi-unit matrix: type once to convert across all units simultaneously.

6. **Matrix Linear Algebra Lab**
   - $2\times 2$, $3\times 3$, $4\times 4$ matrices.
   - Operations: $A + B$, $A - B$, $A \times B$, $\det(A)$, $A^{-1}$, $A^T$, $\mathrm{tr}(A)$, $k \times A$.

7. **Financial Engine**
   - Loan / Mortgage EMI calculator with interest-to-principal breakdown.
   - Compound interest and investment future value projector.
   - Tip and bill splitter.

8. **Mandelbrot & Chaos Explorer**
   - Deep fractal zooming into the Mandelbrot and Julia sets.
   - Customizable color palettes: Cyber Neon, Solar Magma, Quantum, Ice Crystal, Matrix.
   - Real-time M-Iter/sec counter.

## Keyboard Shortcuts

- `0` - `9`: Numeric digits
- `+`, `-`, `*`, `/`, `^`, `%`: Math operators
- `Enter` or `=`: Evaluate calculation
- `Escape`: Clear (AC)
- `Backspace`: Delete character
- `Alt + 1` .. `Alt + 8`: Switch between calculation modes
- `?`: Open keyboard shortcuts and performance guide
