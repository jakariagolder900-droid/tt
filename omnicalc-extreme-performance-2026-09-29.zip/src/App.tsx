import React, { useState, useEffect } from 'react';
import { AppMode } from './types';
import { Header } from './components/Header';
import { ScientificCalc } from './components/ScientificCalc';
import { GraphingStudio } from './components/GraphingStudio';
import { BenchmarkSuite } from './components/BenchmarkSuite';
import { ProgrammerCalc } from './components/ProgrammerCalc';
import { UnitConverter } from './components/UnitConverter';
import { MatrixCalc } from './components/MatrixCalc';
import { FinancialCalc } from './components/FinancialCalc';
import { MandelbrotExplorer } from './components/MandelbrotExplorer';
import { KeyboardShortcutsModal } from './components/KeyboardShortcutsModal';
import { DownloadModal } from './components/DownloadModal';
import { sound } from './utils/audio';

export default function App() {
  const [currentMode, setCurrentMode] = useState<AppMode>(() => {
    try {
      const saved = localStorage.getItem('omnicalc_mode');
      return (saved as AppMode) || 'scientific';
    } catch {
      return 'scientific';
    }
  });

  const [isHelpOpen, setIsHelpOpen] = useState(false);
  const [isDownloadOpen, setIsDownloadOpen] = useState(false);

  useEffect(() => {
    localStorage.setItem('omnicalc_mode', currentMode);
  }, [currentMode]);

  // Global hotkeys for mode switching
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.altKey) {
        if (e.key === '1') {
          e.preventDefault();
          sound.playClick();
          setCurrentMode('scientific');
        } else if (e.key === '2') {
          e.preventDefault();
          sound.playClick();
          setCurrentMode('graphing');
        } else if (e.key === '3') {
          e.preventDefault();
          sound.playClick();
          setCurrentMode('benchmark');
        } else if (e.key === '4') {
          e.preventDefault();
          sound.playClick();
          setCurrentMode('programmer');
        } else if (e.key === '5') {
          e.preventDefault();
          sound.playClick();
          setCurrentMode('units');
        } else if (e.key === '6') {
          e.preventDefault();
          sound.playClick();
          setCurrentMode('matrix');
        } else if (e.key === '7') {
          e.preventDefault();
          sound.playClick();
          setCurrentMode('finance');
        } else if (e.key === '8') {
          e.preventDefault();
          sound.playClick();
          setCurrentMode('fractal');
        }
      } else if (e.key === '?' && !e.target) {
        setIsHelpOpen(true);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-cyan-500 selection:text-slate-950">
      {/* Header bar */}
      <Header
        currentMode={currentMode}
        onSelectMode={setCurrentMode}
        onOpenHelp={() => setIsHelpOpen(true)}
        onOpenDownload={() => setIsDownloadOpen(true)}
      />

      {/* Main Content Area based on mode */}
      <main className="flex-1 flex flex-col py-2 sm:py-4">
        {currentMode === 'scientific' && <ScientificCalc />}
        {currentMode === 'graphing' && <GraphingStudio />}
        {currentMode === 'benchmark' && <BenchmarkSuite />}
        {currentMode === 'programmer' && <ProgrammerCalc />}
        {currentMode === 'units' && <UnitConverter />}
        {currentMode === 'matrix' && <MatrixCalc />}
        {currentMode === 'finance' && <FinancialCalc />}
        {currentMode === 'fractal' && <MandelbrotExplorer />}
      </main>

      {/* Persistent Status Bar */}
      <footer className="border-t border-slate-900 bg-slate-950/90 py-2.5 px-4 text-xs text-slate-500 font-mono">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center space-x-3">
            <span className="flex items-center gap-1.5 text-cyan-400">
              <span className="w-2 h-2 rounded-full bg-emerald-400 inline-block animate-pulse" />
              OmniCalc Extreme
            </span>
            <span>•</span>
            <span>64-bit IEEE 754 & BigInt Engine</span>
          </div>

          <div className="flex items-center space-x-3 text-[11px]">
            <button
              onClick={() => setIsDownloadOpen(true)}
              className="text-cyan-400 hover:text-cyan-300 font-bold transition-colors cursor-pointer flex items-center gap-1"
            >
              📥 Download App / ZIP
            </button>
            <span>•</span>
            <span className="hidden sm:inline text-slate-600">
              Hotkeys: Alt + 1..8 switch modes
            </span>
            <span>•</span>
            <button
              onClick={() => setIsHelpOpen(true)}
              className="text-slate-400 hover:text-cyan-400 transition-colors cursor-pointer"
            >
              Shortcuts Guide [?]
            </button>
          </div>
        </div>
      </footer>

      {/* Keyboard Shortcuts Dialog */}
      <KeyboardShortcutsModal
        isOpen={isHelpOpen}
        onClose={() => setIsHelpOpen(false)}
      />

      {/* Download & Install Modal */}
      <DownloadModal
        isOpen={isDownloadOpen}
        onClose={() => setIsDownloadOpen(false)}
      />
    </div>
  );
}
