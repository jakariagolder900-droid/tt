export type AppMode = 
  | 'scientific'
  | 'graphing'
  | 'benchmark'
  | 'programmer'
  | 'units'
  | 'finance'
  | 'matrix'
  | 'fractal';

export type AngleMode = 'DEG' | 'RAD' | 'GRAD';

export type NumberFormat = 'standard' | 'scientific' | 'engineering' | 'fraction';

export interface HistoryItem {
  id: string;
  expression: string;
  result: string;
  timestamp: number;
  mode: string;
  isFavorite?: boolean;
}

export interface BenchmarkResult {
  id: string;
  name: string;
  description: string;
  durationMs: number;
  opsPerSec: number;
  score: number;
  unit: string;
  details: string;
  status: 'idle' | 'running' | 'completed';
}

export type WordSize = 64 | 32 | 16 | 8;
export type BitRepresentation = 'HEX' | 'DEC' | 'OCT' | 'BIN';

export interface UnitDefinition {
  id: string;
  name: string;
  symbol: string;
  ratioToBase: number; // base is 1
  offset?: number; // for temperature
}

export interface UnitCategory {
  id: string;
  name: string;
  iconName: string;
  baseUnit: string;
  units: UnitDefinition[];
}
