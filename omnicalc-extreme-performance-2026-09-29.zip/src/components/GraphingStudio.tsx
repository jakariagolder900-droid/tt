import React, { useState, useEffect, useRef, useCallback } from 'react';
import { 
  ZoomIn, 
  ZoomOut, 
  Maximize2, 
  Layers, 
  Calculator, 
  Sparkles, 
  Play, 
  HelpCircle,
  TrendingUp,
  BarChart2
} from 'lucide-react';
import { evaluateExpression } from '../utils/mathEngine';
import { sound } from '../utils/audio';

interface FunctionConfig {
  id: string;
  label: string;
  expr: string;
  color: string;
  visible: boolean;
}

export const GraphingStudio: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const [functions, setFunctions] = useState<FunctionConfig[]>([
    { id: 'f1', label: 'f(x)', expr: 'sin(x)', color: '#06b6d4', visible: true },
    { id: 'f2', label: 'g(x)', expr: 'cos(2*x) * 0.5', color: '#a855f7', visible: true },
    { id: 'f3', label: 'h(x)', expr: '0.1 * x^2 - 1', color: '#f59e0b', visible: false },
  ]);

  // Viewport state
  const [view, setView] = useState({
    xMin: -10,
    xMax: 10,
    yMin: -6,
    yMax: 6,
  });

  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const [cursorCoord, setCursorCoord] = useState<{ x: number; y: number } | null>(null);
  const [slopeAtCursor, setSlopeAtCursor] = useState<number | null>(null);

  // Calculus tools: definite integral
  const [showCalculus, setShowCalculus] = useState(false);
  const [intA, setIntA] = useState<number>(-2);
  const [intB, setIntB] = useState<number>(2);
  const [integralResult, setIntegralResult] = useState<number | null>(null);

  const presets = [
    { name: 'Sine & Cosine Waves', f1: 'sin(x)', f2: 'cos(x)' },
    { name: 'Damped Oscillation', f1: 'exp(-0.2*x)*sin(3*x)', f2: 'exp(-0.2*x)' },
    { name: 'Polynomial (Cubic)', f1: 'x^3 - 3*x', f2: '3*x^2 - 3' },
    { name: 'Gaussian Bell Curve', f1: 'exp(-x^2 / 2)', f2: '0' },
    { name: 'Beat Wave Interference', f1: 'sin(5*x) + sin(5.4*x)', f2: '2*cos(0.2*x)' },
    { name: 'Witch of Agnesi', f1: '4 / (x^2 + 1)', f2: '-8*x / (x^2 + 1)^2' },
  ];

  const updateFunction = (id: string, updates: Partial<FunctionConfig>) => {
    setFunctions(prev => prev.map(fn => (fn.id === id ? { ...fn, ...updates } : fn)));
  };

  const evaluateAt = useCallback((expr: string, xVal: number): number | null => {
    try {
      const val = evaluateExpression(expr, {
        angleMode: 'RAD',
        variables: { x: xVal },
      });
      return Number.isFinite(val) && !Number.isNaN(val) ? val : null;
    } catch {
      return null;
    }
  }, []);

  // Compute numerical definite integral using Simpson's 3/8 & Trapezoid rule
  const computeIntegral = useCallback(() => {
    const primary = functions.find(f => f.id === 'f1');
    if (!primary || !primary.expr) return;

    const n = 1000;
    const a = Math.min(intA, intB);
    const b = Math.max(intA, intB);
    const h = (b - a) / n;
    let sum = 0;

    const y0 = evaluateAt(primary.expr, a) ?? 0;
    const yn = evaluateAt(primary.expr, b) ?? 0;
    sum += y0 + yn;

    for (let i = 1; i < n; i++) {
      const x = a + i * h;
      const y = evaluateAt(primary.expr, x) ?? 0;
      sum += (i % 2 === 0 ? 2 : 4) * y;
    }

    const res = (h / 3) * sum * (intA > intB ? -1 : 1);
    setIntegralResult(Number(res.toFixed(6)));
  }, [functions, intA, intB, evaluateAt]);

  useEffect(() => {
    if (showCalculus) {
      computeIntegral();
    }
  }, [showCalculus, intA, intB, functions, computeIntegral]);

  // Canvas drawing loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Handle high DPI display
    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    canvas.width = rect.width * dpr;
    canvas.height = rect.height * dpr;

    ctx.scale(dpr, dpr);
    const width = rect.width;
    const height = rect.height;

    // Transform coordinate helpers
    const toScreenX = (x: number) => ((x - view.xMin) / (view.xMax - view.xMin)) * width;
    const toScreenY = (y: number) => height - ((y - view.yMin) / (view.yMax - view.yMin)) * height;
    const toMathX = (px: number) => view.xMin + (px / width) * (view.xMax - view.xMin);
    const toMathY = (py: number) => view.yMax - (py / height) * (view.yMax - view.yMin);

    // Clear background
    ctx.fillStyle = '#020617'; // slate-950
    ctx.fillRect(0, 0, width, height);

    // Draw grid
    ctx.lineWidth = 1;
    const xRange = view.xMax - view.xMin;
    const yRange = view.yMax - view.yMin;

    // Determine grid step
    let xStep = Math.pow(10, Math.floor(Math.log10(xRange))) / 2;
    if (xRange / xStep > 20) xStep *= 2;
    if (xRange / xStep < 5) xStep /= 2;

    let yStep = Math.pow(10, Math.floor(Math.log10(yRange))) / 2;
    if (yRange / yStep > 20) yStep *= 2;
    if (yRange / yStep < 5) yStep /= 2;

    // Grid lines
    ctx.strokeStyle = '#1e293b'; // slate-800
    ctx.font = '10px JetBrains Mono, monospace';
    ctx.fillStyle = '#64748b';

    const startX = Math.floor(view.xMin / xStep) * xStep;
    for (let x = startX; x <= view.xMax; x += xStep) {
      const sx = toScreenX(x);
      ctx.beginPath();
      ctx.moveTo(sx, 0);
      ctx.lineTo(sx, height);
      ctx.stroke();

      // Number labels
      if (Math.abs(x) > 1e-6) {
        ctx.fillText(Number(x.toFixed(2)).toString(), sx + 3, toScreenY(0) - 4 > height - 12 ? height - 6 : toScreenY(0) - 4 < 14 ? 14 : toScreenY(0) - 4);
      }
    }

    const startY = Math.floor(view.yMin / yStep) * yStep;
    for (let y = startY; y <= view.yMax; y += yStep) {
      const sy = toScreenY(y);
      ctx.beginPath();
      ctx.moveTo(0, sy);
      ctx.lineTo(width, sy);
      ctx.stroke();

      if (Math.abs(y) > 1e-6) {
        ctx.fillText(Number(y.toFixed(2)).toString(), toScreenX(0) + 4 < 4 ? 4 : toScreenX(0) + 4 > width - 30 ? width - 30 : toScreenX(0) + 4, sy - 3);
      }
    }

    // Main Axes (X & Y)
    ctx.strokeStyle = '#475569'; // slate-600
    ctx.lineWidth = 1.5;

    // X Axis
    const originY = toScreenY(0);
    ctx.beginPath();
    ctx.moveTo(0, originY);
    ctx.lineTo(width, originY);
    ctx.stroke();

    // Y Axis
    const originX = toScreenX(0);
    ctx.beginPath();
    ctx.moveTo(originX, 0);
    ctx.lineTo(originX, height);
    ctx.stroke();

    // Shading for definite integral
    if (showCalculus && functions[0].visible && functions[0].expr) {
      const a = Math.min(intA, intB);
      const b = Math.max(intA, intB);
      const sa = Math.max(0, toScreenX(a));
      const sb = Math.min(width, toScreenX(b));

      ctx.fillStyle = 'rgba(6, 182, 212, 0.15)';
      ctx.beginPath();
      ctx.moveTo(toScreenX(a), toScreenY(0));

      const steps = Math.min(400, Math.ceil(sb - sa));
      for (let s = 0; s <= steps; s++) {
        const px = sa + (s / steps) * (sb - sa);
        const mathX = toMathX(px);
        const mathY = evaluateAt(functions[0].expr, mathX) ?? 0;
        ctx.lineTo(px, toScreenY(mathY));
      }
      ctx.lineTo(toScreenX(b), toScreenY(0));
      ctx.closePath();
      ctx.fill();
    }

    // Plot Functions
    functions.forEach(fn => {
      if (!fn.visible || !fn.expr.trim()) return;

      ctx.strokeStyle = fn.color;
      ctx.lineWidth = 2.2;
      ctx.beginPath();

      let isDrawing = false;
      const pixelStep = 1.5;

      for (let px = 0; px <= width; px += pixelStep) {
        const mx = toMathX(px);
        const my = evaluateAt(fn.expr, mx);

        if (my !== null && Number.isFinite(my)) {
          const py = toScreenY(my);

          // Discontinuity check (e.g. tan(x), 1/x asymptotic jump)
          if (py < -height * 2 || py > height * 3) {
            isDrawing = false;
            continue;
          }

          if (!isDrawing) {
            ctx.moveTo(px, py);
            isDrawing = true;
          } else {
            ctx.lineTo(px, py);
          }
        } else {
          isDrawing = false;
        }
      }

      ctx.stroke();
    });

    // Draw Cursor Trace Crosshair & Coordinates
    if (cursorCoord) {
      const primaryFn = functions.find(f => f.visible);
      if (primaryFn) {
        const fVal = evaluateAt(primaryFn.expr, cursorCoord.x);

        if (fVal !== null && Number.isFinite(fVal)) {
          const cx = toScreenX(cursorCoord.x);
          const cy = toScreenY(fVal);

          // Vertical guideline
          ctx.strokeStyle = 'rgba(255, 255, 255, 0.2)';
          ctx.setLineDash([4, 4]);
          ctx.beginPath();
          ctx.moveTo(cx, 0);
          ctx.lineTo(cx, height);
          ctx.stroke();

          // Horizontal guideline
          ctx.beginPath();
          ctx.moveTo(0, cy);
          ctx.lineTo(width, cy);
          ctx.stroke();
          ctx.setLineDash([]);

          // Tangent slope line
          if (slopeAtCursor !== null && Number.isFinite(slopeAtCursor)) {
            ctx.strokeStyle = 'rgba(234, 179, 8, 0.6)'; // amber-500
            ctx.lineWidth = 1.5;
            const dx = (view.xMax - view.xMin) * 0.1;
            const dy = slopeAtCursor * dx;
            ctx.beginPath();
            ctx.moveTo(toScreenX(cursorCoord.x - dx), toScreenY(fVal - dy));
            ctx.lineTo(toScreenX(cursorCoord.x + dx), toScreenY(fVal + dy));
            ctx.stroke();
          }

          // Point marker
          ctx.fillStyle = primaryFn.color;
          ctx.beginPath();
          ctx.arc(cx, cy, 5, 0, Math.PI * 2);
          ctx.fill();
          ctx.strokeStyle = '#ffffff';
          ctx.lineWidth = 2;
          ctx.stroke();
        }
      }
    }
  }, [view, functions, cursorCoord, slopeAtCursor, showCalculus, intA, intB, evaluateAt]);

  // Handle Zoom
  const zoom = (factor: number) => {
    sound.playClick();
    setView(v => {
      const xCenter = (v.xMin + v.xMax) / 2;
      const yCenter = (v.yMin + v.yMax) / 2;
      const xHalf = ((v.xMax - v.xMin) * factor) / 2;
      const yHalf = ((v.yMax - v.yMin) * factor) / 2;
      return {
        xMin: xCenter - xHalf,
        xMax: xCenter + xHalf,
        yMin: yCenter - yHalf,
        yMax: yCenter + yHalf,
      };
    });
  };

  const resetView = () => {
    sound.playClick();
    setView({ xMin: -10, xMax: 10, yMin: -6, yMax: 6 });
  };

  // Canvas Mouse Events
  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    setIsDragging(true);
    setDragStart({ x: e.clientX, y: e.clientY });
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();

    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;

    const mathX = view.xMin + (mouseX / rect.width) * (view.xMax - view.xMin);
    const mathY = view.yMax - (mouseY / rect.height) * (view.yMax - view.yMin);

    setCursorCoord({ x: mathX, y: mathY });

    // Compute numerical slope f'(x)
    const primary = functions.find(f => f.visible);
    if (primary && primary.expr) {
      const eps = 0.0001;
      const y1 = evaluateAt(primary.expr, mathX + eps);
      const y0 = evaluateAt(primary.expr, mathX - eps);
      if (y1 !== null && y0 !== null) {
        setSlopeAtCursor((y1 - y0) / (2 * eps));
      }
    }

    if (isDragging) {
      const dx = e.clientX - dragStart.x;
      const dy = e.clientY - dragStart.y;

      const scaleX = (view.xMax - view.xMin) / rect.width;
      const scaleY = (view.yMax - view.yMin) / rect.height;

      setView(v => ({
        xMin: v.xMin - dx * scaleX,
        xMax: v.xMax - dx * scaleX,
        yMin: v.yMin + dy * scaleY,
        yMax: v.yMax + dy * scaleY,
      }));

      setDragStart({ x: e.clientX, y: e.clientY });
    }
  };

  const handleMouseUp = () => setIsDragging(false);
  const handleMouseLeave = () => {
    setIsDragging(false);
    setCursorCoord(null);
    setSlopeAtCursor(null);
  };

  const handleWheel = (e: React.WheelEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    const factor = e.deltaY > 0 ? 1.15 : 0.85;
    zoom(factor);
  };

  return (
    <div className="max-w-7xl mx-auto p-3 sm:p-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
      {/* Canvas Viewport */}
      <div className="lg:col-span-8 flex flex-col space-y-3">
        <div className="relative rounded-2xl overflow-hidden border border-slate-800 bg-slate-950 shadow-2xl">
          <canvas
            ref={canvasRef}
            onMouseDown={handleMouseDown}
            onMouseMove={handleMouseMove}
            onMouseUp={handleMouseUp}
            onMouseLeave={handleMouseLeave}
            onWheel={handleWheel}
            className="w-full h-[450px] sm:h-[550px] cursor-crosshair block"
          />

          {/* Floating Controls Overlay */}
          <div className="absolute top-3 right-3 flex items-center space-x-1.5 bg-slate-900/80 backdrop-blur-md p-1.5 rounded-xl border border-slate-800 shadow-lg">
            <button
              onClick={() => zoom(0.8)}
              className="p-2 rounded-lg hover:bg-slate-800 text-slate-300 hover:text-cyan-400 transition-colors cursor-pointer"
              title="Zoom In"
            >
              <ZoomIn className="w-4 h-4" />
            </button>
            <button
              onClick={() => zoom(1.25)}
              className="p-2 rounded-lg hover:bg-slate-800 text-slate-300 hover:text-cyan-400 transition-colors cursor-pointer"
              title="Zoom Out"
            >
              <ZoomOut className="w-4 h-4" />
            </button>
            <button
              onClick={resetView}
              className="p-2 rounded-lg hover:bg-slate-800 text-slate-300 hover:text-white transition-colors cursor-pointer"
              title="Reset View to Origin"
            >
              <Maximize2 className="w-4 h-4" />
            </button>
          </div>

          {/* Real-time Coordinate & Slope Tag */}
          {cursorCoord && (
            <div className="absolute bottom-3 left-3 bg-slate-900/90 backdrop-blur-md px-3 py-1.5 rounded-xl border border-slate-800 text-xs font-mono flex items-center space-x-3 shadow-lg">
              <span className="text-cyan-400">
                x: {cursorCoord.x.toFixed(3)}
              </span>
              {functions[0].visible && (
                <span className="text-indigo-300">
                  f(x): {(evaluateAt(functions[0].expr, cursorCoord.x) ?? 0).toFixed(3)}
                </span>
              )}
              {slopeAtCursor !== null && (
                <span className="text-amber-400 hidden sm:inline">
                  f&apos;(x) slope: {slopeAtCursor.toFixed(3)}
                </span>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Function Control & Calculus Panel */}
      <div className="lg:col-span-4 flex flex-col space-y-4">
        {/* Function Inputs */}
        <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <div className="flex items-center space-x-2">
              <Layers className="w-4 h-4 text-cyan-400" />
              <h2 className="font-semibold text-sm text-slate-200">Plot Functions</h2>
            </div>
            <span className="text-[11px] text-slate-500 font-mono">2D Cartesian</span>
          </div>

          <div className="space-y-3">
            {functions.map(fn => (
              <div key={fn.id} className="space-y-1">
                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center space-x-2">
                    <span
                      className="w-2.5 h-2.5 rounded-full"
                      style={{ backgroundColor: fn.color }}
                    />
                    <span className="font-mono font-bold" style={{ color: fn.color }}>
                      {fn.label}
                    </span>
                  </div>
                  <label className="flex items-center space-x-1.5 text-[11px] text-slate-400 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={fn.visible}
                      onChange={e => updateFunction(fn.id, { visible: e.target.checked })}
                      className="rounded bg-slate-950 border-slate-800 text-cyan-500 focus:ring-0"
                    />
                    <span>Visible</span>
                  </label>
                </div>
                <input
                  type="text"
                  value={fn.expr}
                  onChange={e => updateFunction(fn.id, { expr: e.target.value })}
                  placeholder="e.g. sin(x), x^2 - 4"
                  className="w-full bg-slate-950 px-3 py-2 rounded-xl border border-slate-800 text-sm font-mono text-white focus:border-cyan-500 outline-none transition-colors"
                />
              </div>
            ))}
          </div>

          {/* Calculus Tools Toggle */}
          <div className="pt-2">
            <button
              onClick={() => {
                sound.playClick();
                setShowCalculus(!showCalculus);
              }}
              className={`w-full py-2 px-3 rounded-xl border flex items-center justify-between text-xs font-semibold transition-all cursor-pointer ${
                showCalculus
                  ? 'bg-cyan-500/10 border-cyan-500/40 text-cyan-400'
                  : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              <div className="flex items-center space-x-2">
                <TrendingUp className="w-3.5 h-3.5" />
                <span>Calculus Engine (∫ Definite Integral)</span>
              </div>
              <span>{showCalculus ? 'Close' : 'Compute'}</span>
            </button>

            {showCalculus && (
              <div className="mt-3 p-3 rounded-xl bg-slate-950 border border-slate-800/80 space-y-2.5 text-xs">
                <p className="text-slate-400 text-[11px]">
                  Calculate shaded area under f(x) from x = a to x = b:
                </p>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-slate-500 text-[10px]">Lower bound (a)</label>
                    <input
                      type="number"
                      value={intA}
                      onChange={e => setIntA(Number(e.target.value))}
                      className="w-full bg-slate-900 px-2.5 py-1 rounded border border-slate-800 text-cyan-400 font-mono"
                    />
                  </div>
                  <div>
                    <label className="text-slate-500 text-[10px]">Upper bound (b)</label>
                    <input
                      type="number"
                      value={intB}
                      onChange={e => setIntB(Number(e.target.value))}
                      className="w-full bg-slate-900 px-2.5 py-1 rounded border border-slate-800 text-cyan-400 font-mono"
                    />
                  </div>
                </div>

                <div className="pt-1 flex items-center justify-between">
                  <span className="text-slate-400 font-mono">∫ [a, b] f(x) dx =</span>
                  <span className="text-sm font-mono font-bold text-cyan-400">
                    {integralResult !== null ? integralResult : 'Computing...'}
                  </span>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Presets Library */}
        <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-2.5">
          <div className="flex items-center space-x-2 pb-2 border-b border-slate-800">
            <Sparkles className="w-4 h-4 text-indigo-400" />
            <h3 className="font-semibold text-sm text-slate-200">Curve Library & Presets</h3>
          </div>

          <div className="grid grid-cols-1 gap-1.5 max-h-[220px] overflow-y-auto pr-1">
            {presets.map(p => (
              <button
                key={p.name}
                onClick={() => {
                  sound.playClick();
                  setFunctions([
                    { id: 'f1', label: 'f(x)', expr: p.f1, color: '#06b6d4', visible: true },
                    { id: 'f2', label: 'g(x)', expr: p.f2, color: '#a855f7', visible: p.f2 !== '0' },
                    { id: 'f3', label: 'h(x)', expr: '', color: '#f59e0b', visible: false },
                  ]);
                }}
                className="p-2 rounded-xl bg-slate-950/60 hover:bg-slate-950 border border-slate-800/80 hover:border-slate-700 text-left transition-all group cursor-pointer"
              >
                <div className="text-xs font-medium text-slate-300 group-hover:text-cyan-400">
                  {p.name}
                </div>
                <div className="text-[10px] font-mono text-slate-500 truncate">
                  f(x) = {p.f1}
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
