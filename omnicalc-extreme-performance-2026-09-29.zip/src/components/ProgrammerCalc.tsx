import React, { useState } from 'react';
import { 
  Binary, 
  RotateCw, 
  RotateCcw, 
  Layers, 
  Copy, 
  Check, 
  Trash2,
  Code
} from 'lucide-react';
import { WordSize, BitRepresentation } from '../types';
import { sound } from '../utils/audio';

export const ProgrammerCalc: React.FC = () => {
  const [val, setVal] = useState<bigint>(0n);
  const [wordSize, setWordSize] = useState<WordSize>(64);
  const [isSigned, setIsSigned] = useState<boolean>(false);
  const [activeRadix, setActiveRadix] = useState<BitRepresentation>('DEC');
  const [pendingOp, setPendingOp] = useState<string | null>(null);
  const [operandA, setOperandA] = useState<bigint | null>(null);
  const [copiedRadix, setCopiedRadix] = useState<string | null>(null);

  // Mask value according to current word size
  const getMask = (size: WordSize): bigint => {
    switch (size) {
      case 8:
        return 0xffn;
      case 16:
        return 0xffffn;
      case 32:
        return 0xffffffffn;
      case 64:
      default:
        return 0xffffffffffffffffn;
    }
  };

  const maskValue = (v: bigint, size: WordSize = wordSize): bigint => {
    return v & getMask(size);
  };

  const getSignedValue = (v: bigint, size: WordSize = wordSize): bigint => {
    const unsigned = maskValue(v, size);
    const signBit = 1n << BigInt(size - 1);
    if (unsigned & signBit) {
      // Negative
      return unsigned - (1n << BigInt(size));
    }
    return unsigned;
  };

  // Conversions
  const maskedVal = maskValue(val);
  const hexStr = maskedVal.toString(16).toUpperCase();
  const decStr = isSigned ? getSignedValue(val).toString(10) : maskedVal.toString(10);
  const octStr = maskedVal.toString(8);
  const binRaw = maskedVal.toString(2).padStart(wordSize, '0');

  // Format binary into 4-bit nibbles
  const binFormatted = binRaw.match(/.{1,4}/g)?.join(' ') || binRaw;

  // Toggle specific bit in the bitboard (0 to wordSize - 1)
  const toggleBit = (bitIndex: number) => {
    sound.playClick();
    const bitMask = 1n << BigInt(bitIndex);
    const newVal = val ^ bitMask;
    setVal(maskValue(newVal));
  };

  const handleDigit = (d: string) => {
    sound.playClick();
    const base = activeRadix === 'HEX' ? 16 : activeRadix === 'DEC' ? 10 : activeRadix === 'OCT' ? 8 : 2;

    try {
      const currentStr = activeRadix === 'HEX' ? hexStr : activeRadix === 'DEC' ? decStr : activeRadix === 'OCT' ? octStr : binRaw;
      const nextStr = currentStr === '0' ? d : currentStr + d;
      const nextVal = BigInt(activeRadix === 'HEX' ? '0x' + nextStr : activeRadix === 'OCT' ? '0o' + nextStr : activeRadix === 'BIN' ? '0b' + nextStr : nextStr);
      setVal(maskValue(nextVal));
    } catch {
      // Ignore input error
    }
  };

  const handleClear = () => {
    sound.playClear();
    setVal(0n);
    setOperandA(null);
    setPendingOp(null);
  };

  const handleBackspace = () => {
    sound.playClick();
    const str = activeRadix === 'HEX' ? hexStr : activeRadix === 'DEC' ? decStr : activeRadix === 'OCT' ? octStr : binRaw;
    if (str.length <= 1) {
      setVal(0n);
    } else {
      const sliced = str.slice(0, -1);
      try {
        const nextVal = BigInt(activeRadix === 'HEX' ? '0x' + sliced : activeRadix === 'OCT' ? '0o' + sliced : activeRadix === 'BIN' ? '0b' + sliced : sliced);
        setVal(maskValue(nextVal));
      } catch {
        setVal(0n);
      }
    }
  };

  const applyBitwiseOp = (op: string) => {
    sound.playOperator();
    if (op === 'NOT') {
      setVal(maskValue(~val));
      return;
    }

    setOperandA(val);
    setPendingOp(op);
    setVal(0n);
  };

  const handleEquals = () => {
    if (operandA === null || !pendingOp) return;
    sound.playEqual();

    let res = 0n;
    switch (pendingOp) {
      case 'AND':
        res = operandA & val;
        break;
      case 'OR':
        res = operandA | val;
        break;
      case 'XOR':
        res = operandA ^ val;
        break;
      case 'NAND':
        res = ~(operandA & val);
        break;
      case 'NOR':
        res = ~(operandA | val);
        break;
      case 'XNOR':
        res = ~(operandA ^ val);
        break;
      case 'LSH':
        res = operandA << (val & 63n);
        break;
      case 'RSH':
        res = operandA >> (val & 63n);
        break;
      case '+':
        res = operandA + val;
        break;
      case '-':
        res = operandA - val;
        break;
      case '*':
        res = operandA * val;
        break;
      case '/':
        if (val === 0n) {
          sound.playError();
          return;
        }
        res = operandA / val;
        break;
      case '%':
        if (val === 0n) return;
        res = operandA % val;
        break;
    }

    setVal(maskValue(res));
    setOperandA(null);
    setPendingOp(null);
  };

  // ASCII preview of low bytes
  const getAsciiPreview = (v: bigint): string => {
    let s = '';
    let temp = v;
    for (let i = 0; i < 8; i++) {
      const byte = Number(temp & 0xffn);
      if (byte >= 32 && byte <= 126) {
        s = String.fromCharCode(byte) + s;
      } else if (byte > 0) {
        s = '.' + s;
      }
      temp >>= 8n;
    }
    return s || '(none)';
  };

  const copyRadix = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedRadix(id);
    setTimeout(() => setCopiedRadix(null), 1500);
  };

  // Check if button is enabled in current radix
  const isDigitValid = (char: string) => {
    if (activeRadix === 'BIN') return ['0', '1'].includes(char);
    if (activeRadix === 'OCT') return ['0', '1', '2', '3', '4', '5', '6', '7'].includes(char);
    if (activeRadix === 'DEC') return /[0-9]/.test(char);
    if (activeRadix === 'HEX') return /[0-9A-Fa-f]/.test(char);
    return false;
  };

  return (
    <div className="max-w-7xl mx-auto p-3 sm:p-6 space-y-6">
      {/* Top Configuration: Word Size, Sign Toggle */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-3 rounded-2xl bg-slate-900 border border-slate-800 text-xs">
        <div className="flex items-center space-x-2">
          <span className="text-slate-400 font-medium">Word Size:</span>
          {([64, 32, 16, 8] as WordSize[]).map(size => (
            <button
              key={size}
              onClick={() => {
                sound.playClick();
                setWordSize(size);
                setVal(v => maskValue(v, size));
              }}
              className={`px-3 py-1 rounded-lg font-mono font-bold transition-all cursor-pointer ${
                wordSize === size
                  ? 'bg-cyan-500 text-slate-950 shadow-sm shadow-cyan-500/30'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
              }`}
            >
              {size === 64 ? 'QWORD (64)' : size === 32 ? 'DWORD (32)' : size === 16 ? 'WORD (16)' : 'BYTE (8)'}
            </button>
          ))}
        </div>

        <div className="flex items-center space-x-3">
          <button
            onClick={() => {
              sound.playClick();
              setIsSigned(!isSigned);
            }}
            className={`px-3 py-1 rounded-lg font-mono text-xs font-semibold border transition-all cursor-pointer ${
              isSigned
                ? 'bg-indigo-600/20 border-indigo-500 text-indigo-300'
                : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
            }`}
          >
            Mode: {isSigned ? 'SIGNED (Two’s Comp)' : 'UNSIGNED'}
          </button>
          <div className="text-slate-400 text-xs font-mono hidden sm:block">
            ASCII: <span className="text-cyan-400 font-bold">{getAsciiPreview(val)}</span>
          </div>
        </div>
      </div>

      {/* Synchronized Radix Display Rows */}
      <div className="p-4 sm:p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-2 shadow-2xl">
        {(
          [
            { id: 'HEX', label: 'HEX', val: hexStr },
            { id: 'DEC', label: 'DEC', val: decStr },
            { id: 'OCT', label: 'OCT', val: octStr },
            { id: 'BIN', label: 'BIN', val: binFormatted },
          ] as { id: BitRepresentation; label: string; val: string }[]
        ).map(item => {
          const isActive = activeRadix === item.id;
          return (
            <div
              key={item.id}
              onClick={() => {
                sound.playClick();
                setActiveRadix(item.id);
              }}
              className={`p-2.5 rounded-xl border flex items-center justify-between transition-all cursor-pointer ${
                isActive
                  ? 'bg-slate-950 border-cyan-500/50 shadow-sm'
                  : 'bg-slate-950/40 border-slate-800/80 hover:bg-slate-950/80'
              }`}
            >
              <div className="flex items-center space-x-3">
                <span
                  className={`text-xs font-mono font-bold w-10 ${
                    isActive ? 'text-cyan-400' : 'text-slate-500'
                  }`}
                >
                  {item.label}
                </span>
                <span
                  className={`font-mono text-sm sm:text-base break-all tracking-wider ${
                    isActive ? 'text-white font-bold' : 'text-slate-400'
                  }`}
                >
                  {item.val || '0'}
                </span>
              </div>

              <button
                onClick={e => {
                  e.stopPropagation();
                  copyRadix(item.val, item.id);
                }}
                className="p-1 rounded hover:bg-slate-800 text-slate-500 hover:text-cyan-400 transition-colors ml-2"
                title={`Copy ${item.label}`}
              >
                {copiedRadix === item.id ? (
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                ) : (
                  <Copy className="w-3.5 h-3.5" />
                )}
              </button>
            </div>
          );
        })}
      </div>

      {/* Interactive 64-Bit Bitboard */}
      <div className="p-4 sm:p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
        <div className="flex items-center justify-between pb-2 border-b border-slate-800">
          <div className="flex items-center space-x-2">
            <Binary className="w-4 h-4 text-cyan-400" />
            <h3 className="font-semibold text-xs text-slate-200 uppercase tracking-wider">
              Interactive 64-Bit Matrix (Click to toggle bits)
            </h3>
          </div>
          <span className="text-[11px] font-mono text-slate-500">MSB (63) ➔ LSB (0)</span>
        </div>

        {/* 64 Bit Grid (4 rows of 16 bits) */}
        <div className="space-y-2">
          {[0, 1, 2, 3].map(rowIdx => {
            const startBit = 63 - rowIdx * 16;
            const endBit = startBit - 15;
            if (startBit >= wordSize && endBit >= wordSize) return null;

            return (
              <div key={rowIdx} className="space-y-1">
                <div className="flex justify-between text-[10px] font-mono text-slate-500 px-1">
                  <span>Bit {startBit}</span>
                  <span>Bit {endBit}</span>
                </div>
                <div className="grid grid-cols-16 gap-1">
                  {Array.from({ length: 16 }, (_, i) => {
                    const bitNum = startBit - i;
                    const isEnabled = bitNum < wordSize;
                    const bitVal = isEnabled ? ((val >> BigInt(bitNum)) & 1n) === 1n : false;

                    return (
                      <button
                        key={bitNum}
                        disabled={!isEnabled}
                        onClick={() => toggleBit(bitNum)}
                        className={`h-8 sm:h-9 rounded-md font-mono text-xs font-bold transition-all flex flex-col items-center justify-center cursor-pointer ${
                          !isEnabled
                            ? 'bg-slate-950/40 text-slate-700 cursor-not-allowed border border-slate-900'
                            : bitVal
                            ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/30'
                            : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800 hover:border-slate-700'
                        }`}
                        title={`Bit ${bitNum}: ${bitVal ? '1' : '0'}`}
                      >
                        <span>{bitVal ? '1' : '0'}</span>
                        <span className="text-[8px] opacity-40 -mt-0.5">{bitNum}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Programmer Keypad: Bitwise & Arithmetic */}
      <div className="grid grid-cols-2 sm:grid-cols-6 gap-3">
        {/* Bitwise operations */}
        <div className="col-span-2 sm:col-span-2 grid grid-cols-2 gap-2">
          <button onClick={() => applyBitwiseOp('AND')} className="calc-btn text-cyan-300 bg-slate-900">AND</button>
          <button onClick={() => applyBitwiseOp('OR')} className="calc-btn text-cyan-300 bg-slate-900">OR</button>
          <button onClick={() => applyBitwiseOp('XOR')} className="calc-btn text-cyan-300 bg-slate-900">XOR</button>
          <button onClick={() => applyBitwiseOp('NOT')} className="calc-btn text-cyan-300 bg-slate-900">NOT</button>
          <button onClick={() => applyBitwiseOp('NAND')} className="calc-btn text-cyan-300 bg-slate-900">NAND</button>
          <button onClick={() => applyBitwiseOp('NOR')} className="calc-btn text-cyan-300 bg-slate-900">NOR</button>
          <button onClick={() => applyBitwiseOp('LSH')} className="calc-btn text-indigo-300 bg-slate-900">LSH &lt;&lt;</button>
          <button onClick={() => applyBitwiseOp('RSH')} className="calc-btn text-indigo-300 bg-slate-900">RSH &gt;&gt;</button>
        </div>

        {/* Hex and decimal digits */}
        <div className="col-span-2 sm:col-span-4 grid grid-cols-5 gap-2">
          {['A', 'B', 'C', 'D', 'E', 'F'].map(char => (
            <button
              key={char}
              disabled={!isDigitValid(char)}
              onClick={() => handleDigit(char)}
              className={`calc-btn font-mono font-bold ${
                isDigitValid(char)
                  ? 'text-cyan-400 bg-slate-900 hover:bg-slate-800'
                  : 'text-slate-700 bg-slate-950/40 cursor-not-allowed border border-slate-900'
              }`}
            >
              {char}
            </button>
          ))}

          <button onClick={handleClear} className="calc-btn text-rose-400 bg-rose-950/20 border-rose-900/40 font-bold">
            CLR
          </button>
          <button onClick={handleBackspace} className="calc-btn text-amber-400 bg-amber-950/20 border-amber-900/40">
            DEL
          </button>
          <button onClick={() => applyBitwiseOp('/')} className="calc-btn text-slate-300 bg-slate-900">÷</button>
          <button onClick={() => applyBitwiseOp('*')} className="calc-btn text-slate-300 bg-slate-900">×</button>

          {['7', '8', '9'].map(d => (
            <button
              key={d}
              disabled={!isDigitValid(d)}
              onClick={() => handleDigit(d)}
              className={`calc-btn ${isDigitValid(d) ? 'calc-num-btn' : 'text-slate-700 bg-slate-950/40 cursor-not-allowed'}`}
            >
              {d}
            </button>
          ))}
          <button onClick={() => applyBitwiseOp('-')} className="calc-btn text-slate-300 bg-slate-900">−</button>
          <button onClick={() => applyBitwiseOp('+')} className="calc-btn text-slate-300 bg-slate-900">+</button>

          {['4', '5', '6'].map(d => (
            <button
              key={d}
              disabled={!isDigitValid(d)}
              onClick={() => handleDigit(d)}
              className={`calc-btn ${isDigitValid(d) ? 'calc-num-btn' : 'text-slate-700 bg-slate-950/40 cursor-not-allowed'}`}
            >
              {d}
            </button>
          ))}
          <button onClick={() => applyBitwiseOp('%')} className="calc-btn text-slate-300 bg-slate-900">%</button>
          <button
            onClick={handleEquals}
            className="row-span-2 calc-btn text-slate-950 bg-gradient-to-r from-cyan-400 to-indigo-400 hover:from-cyan-300 hover:to-indigo-300 font-black shadow-lg shadow-cyan-500/20 text-xl"
          >
            =
          </button>

          {['1', '2', '3'].map(d => (
            <button
              key={d}
              disabled={!isDigitValid(d)}
              onClick={() => handleDigit(d)}
              className={`calc-btn ${isDigitValid(d) ? 'calc-num-btn' : 'text-slate-700 bg-slate-950/40 cursor-not-allowed'}`}
            >
              {d}
            </button>
          ))}
          <button
            disabled={!isDigitValid('0')}
            onClick={() => handleDigit('0')}
            className={`col-span-1 calc-btn ${isDigitValid('0') ? 'calc-num-btn' : 'text-slate-700 bg-slate-950/40 cursor-not-allowed'}`}
          >
            0
          </button>
        </div>
      </div>
    </div>
  );
};
