import React, { useState, useEffect, useRef } from 'react';
import { 
  ZoomIn, 
  ZoomOut, 
  RotateCcw, 
  Palette, 
  Sparkles, 
  Layers, 
  Activity, 
  Compass,
  Cpu
} from 'lucide-react';
import { sound } from '../utils/audio';

type ColorPalette = 'cyber' | 'magma' | 'quantum' | 'ice' | 'matrix';

export const MandelbrotExplorer: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const [center, setCenter] = useState({ r: -0.7, i: 0.0 });
  const [zoomLevel, setZoomLevel] = useState(1);
  const [maxIter, setMaxIter] = useState(250);
  const [palette, setPalette] = useState<ColorPalette>('cyber');
  const [mode, setMode] = useState<'mandelbrot' | 'julia'>('mandelbrot');
  const [juliaC, setJuliaC] = useState({ r: -0.7, i: 0.27015 });

  // Compute metrics
  const [renderTimeMs, setRenderTimeMs] = useState(0);
  const [totalItersComputed, setTotalItersComputed] = useState(0);

  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });

  const presets = [
    { name: 'Full Mandelbrot', r: -0.7, i: 0.0, zoom: 1, mode: 'mandelbrot' },
    { name: 'Seahorse Valley', r: -0.743643887037158704752191506114774, i: 0.131825904205311970493132056385139, zoom: 250, mode: 'mandelbrot' },
    { name: 'Elephant Valley', r: 0.275, i: 0.006, zoom: 45, mode: 'mandelbrot' },
    { name: 'Julia Dragon', r: 0, i: 0, zoom: 1, mode: 'julia', jr: -0.8, ji: 0.156 },
    { name: 'Dendrite Fractal', r: 0, i: 0, zoom: 1.2, mode: 'julia', jr: -0.4, ji: 0.6 },
  ];

  // Palette color generator
  const getColor = (iter: number, max: number, p: ColorPalette): [number, number, number] => {
    if (iter === max) return [4, 7, 20]; // slate-950

    const t = iter / max;

    switch (p) {
      case 'cyber': {
        // Cyan to Purple to Magenta
        const r = Math.floor(Math.sin(t * 10) * 127 + 128);
        const g = Math.floor(Math.sin(t * 10 + 2) * 127 + 128);
        const b = Math.floor(Math.sin(t * 10 + 4) * 127 + 128);
        return [r, g, b];
      }
      case 'magma': {
        // Red, Orange, Gold
        const r = Math.min(255, Math.floor(t * 400));
        const g = Math.min(255, Math.floor(Math.pow(t, 2) * 350));
        const b = Math.min(255, Math.floor(Math.pow(t, 4) * 255));
        return [r, g, b];
      }
      case 'quantum': {
        // Emerald / Cyan / Deep Blue
        const r = Math.floor(Math.sin(t * 8) * 40);
        const g = Math.floor(Math.sin(t * 8 + 1) * 120 + 130);
        const b = Math.floor(Math.cos(t * 8) * 120 + 135);
        return [Math.max(0, r), Math.max(0, g), Math.max(0, b)];
      }
      case 'ice': {
        const c = Math.floor(Math.pow(t, 0.4) * 255);
        return [Math.floor(c * 0.7), Math.floor(c * 0.9), c];
      }
      case 'matrix': {
        const g = Math.floor(t * 255);
        return [0, g, Math.floor(g * 0.3)];
      }
    }
  };

  const renderFractal = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;
    const imgData = ctx.createImageData(width, height);
    const data = imgData.data;

    const t0 = performance.now();
    let itersCount = 0;

    const scale = 3.0 / (zoomLevel * Math.min(width, height));
    const rOffset = center.r - (width / 2) * scale;
    const iOffset = center.i - (height / 2) * scale;

    const isJulia = mode === 'julia';
    const cReal = juliaC.r;
    const cImag = juliaC.i;

    let pIdx = 0;
    for (let py = 0; py < height; py++) {
      const imagCoord = iOffset + py * scale;
      for (let px = 0; px < width; px++) {
        const realCoord = rOffset + px * scale;

        let zr = isJulia ? realCoord : 0.0;
        let zi = isJulia ? imagCoord : 0.0;
        const cr = isJulia ? cReal : realCoord;
        const ci = isJulia ? cImag : imagCoord;

        let iter = 0;
        while (zr * zr + zi * zi <= 4.0 && iter < maxIter) {
          const nzr = zr * zr - zi * zi + cr;
          zi = 2.0 * zr * zi + ci;
          zr = nzr;
          iter++;
        }

        itersCount += iter;
        const [r, g, b] = getColor(iter, maxIter, palette);

        data[pIdx] = r;
        data[pIdx + 1] = g;
        data[pIdx + 2] = b;
        data[pIdx + 3] = 255;
        pIdx += 4;
      }
    }

    ctx.putImageData(imgData, 0, 0);

    const dur = Math.max(1, performance.now() - t0);
    setRenderTimeMs(Math.round(dur * 10) / 10);
    setTotalItersComputed(itersCount);
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (canvas) {
      canvas.width = 640;
      canvas.height = 440;
      renderFractal();
    }
  }, [center, zoomLevel, maxIter, palette, mode, juliaC]);

  const handleZoom = (factor: number) => {
    sound.playClick();
    setZoomLevel(z => Math.max(0.2, z * factor));
  };

  const handleReset = () => {
    sound.playClick();
    setCenter({ r: -0.7, i: 0.0 });
    setZoomLevel(1);
    setMaxIter(250);
    setMode('mandelbrot');
  };

  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    setIsDragging(true);
    setDragStart({ x: e.clientX, y: e.clientY });
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDragging || !canvasRef.current) return;
    const dx = e.clientX - dragStart.x;
    const dy = e.clientY - dragStart.y;

    const scale = 3.0 / (zoomLevel * Math.min(canvasRef.current.width, canvasRef.current.height));
    setCenter(c => ({
      r: c.r - dx * scale,
      i: c.i - dy * scale,
    }));
    setDragStart({ x: e.clientX, y: e.clientY });
  };

  const handleMouseUp = () => setIsDragging(false);

  const mips = renderTimeMs > 0 ? ((totalItersComputed / (renderTimeMs / 1000)) / 1_000_000).toFixed(1) : '0';

  return (
    <div className="max-w-7xl mx-auto p-3 sm:p-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
      {/* Canvas Viewport */}
      <div className="lg:col-span-8 flex flex-col space-y-3">
        <div className="relative rounded-2xl overflow-hidden border border-slate-800 bg-slate-950 shadow-2xl flex items-center justify-center">
          <canvas
            ref={canvasRef}
            onMouseDown={handleMouseDown}
            onMouseMove={handleMouseMove}
            onMouseUp={handleMouseUp}
            onMouseLeave={handleMouseUp}
            className="cursor-grab active:cursor-grabbing w-full h-[440px] block"
          />

          {/* Floating Zoom & Controls */}
          <div className="absolute top-3 right-3 flex items-center space-x-1.5 bg-slate-900/80 backdrop-blur-md p-1.5 rounded-xl border border-slate-800 shadow-lg">
            <button
              onClick={() => handleZoom(1.8)}
              className="p-2 rounded-lg hover:bg-slate-800 text-slate-300 hover:text-cyan-400 transition-colors cursor-pointer"
              title="Zoom In"
            >
              <ZoomIn className="w-4 h-4" />
            </button>
            <button
              onClick={() => handleZoom(0.55)}
              className="p-2 rounded-lg hover:bg-slate-800 text-slate-300 hover:text-cyan-400 transition-colors cursor-pointer"
              title="Zoom Out"
            >
              <ZoomOut className="w-4 h-4" />
            </button>
            <button
              onClick={handleReset}
              className="p-2 rounded-lg hover:bg-slate-800 text-slate-300 hover:text-white transition-colors cursor-pointer"
              title="Reset View"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>

          {/* Live Performance Meter Chip */}
          <div className="absolute bottom-3 left-3 bg-slate-900/90 backdrop-blur-md px-3 py-1.5 rounded-xl border border-slate-800 text-xs font-mono flex items-center space-x-3 shadow-lg">
            <div className="flex items-center space-x-1.5 text-cyan-400">
              <Cpu className="w-3.5 h-3.5" />
              <span>{renderTimeMs} ms</span>
            </div>
            <span className="text-slate-500">•</span>
            <span className="text-indigo-300">
              {totalItersComputed.toLocaleString()} iters
            </span>
            <span className="text-slate-500 hidden sm:inline">•</span>
            <span className="text-amber-400 hidden sm:inline font-bold">
              {mips} M-Iter/s
            </span>
          </div>
        </div>
      </div>

      {/* Control Panel */}
      <div className="lg:col-span-4 flex flex-col space-y-4">
        {/* Fractal Configuration */}
        <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <div className="flex items-center space-x-2">
              <Sparkles className="w-4 h-4 text-cyan-400" />
              <h2 className="font-semibold text-sm text-slate-200">Fractal Hardware Stress</h2>
            </div>
            <span className="text-[11px] text-slate-400 font-mono">Zoom: {zoomLevel.toFixed(1)}x</span>
          </div>

          {/* Mode Switcher */}
          <div className="flex rounded-xl bg-slate-950 p-1 border border-slate-800">
            <button
              onClick={() => {
                sound.playClick();
                setMode('mandelbrot');
              }}
              className={`flex-1 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                mode === 'mandelbrot'
                  ? 'bg-cyan-500 text-slate-950 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Mandelbrot Set
            </button>
            <button
              onClick={() => {
                sound.playClick();
                setMode('julia');
              }}
              className={`flex-1 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                mode === 'julia'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Julia Set
            </button>
          </div>

          {/* Iteration Depth Slider */}
          <div className="space-y-1.5">
            <div className="flex justify-between items-center text-xs">
              <span className="text-slate-400">Compute Depth (Max Iterations):</span>
              <span className="font-mono text-cyan-400 font-bold">{maxIter}</span>
            </div>
            <input
              type="range"
              min={50}
              max={1000}
              step={25}
              value={maxIter}
              onChange={e => setMaxIter(Number(e.target.value))}
              className="w-full accent-cyan-400 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-500 font-mono">
              <span>Fast (50)</span>
              <span>Ultra Depth (1,000)</span>
            </div>
          </div>

          {/* Color Palettes */}
          <div className="space-y-2">
            <span className="text-xs text-slate-400 flex items-center gap-1.5">
              <Palette className="w-3.5 h-3.5 text-indigo-400" />
              <span>Color Shader Palette:</span>
            </span>
            <div className="grid grid-cols-3 gap-1.5 text-xs">
              {(
                [
                  { id: 'cyber', name: 'Cyber Neon' },
                  { id: 'magma', name: 'Solar Magma' },
                  { id: 'quantum', name: 'Quantum' },
                  { id: 'ice', name: 'Ice Crystal' },
                  { id: 'matrix', name: 'Matrix' },
                ] as { id: ColorPalette; name: string }[]
              ).map(p => (
                <button
                  key={p.id}
                  onClick={() => {
                    sound.playClick();
                    setPalette(p.id);
                  }}
                  className={`py-1.5 px-2 rounded-lg border text-center transition-all cursor-pointer ${
                    palette === p.id
                      ? 'bg-cyan-500/20 border-cyan-500 text-cyan-300 font-semibold'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {p.name}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Fractal Presets */}
        <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-2.5">
          <h3 className="font-semibold text-xs text-slate-300 uppercase tracking-wider flex items-center gap-2">
            <Compass className="w-3.5 h-3.5 text-cyan-400" />
            <span>Notable Coordinates</span>
          </h3>

          <div className="grid grid-cols-1 gap-1.5">
            {presets.map(p => (
              <button
                key={p.name}
                onClick={() => {
                  sound.playClick();
                  setMode(p.mode as 'mandelbrot' | 'julia');
                  setCenter({ r: p.r, i: p.i });
                  setZoomLevel(p.zoom);
                  if (p.jr !== undefined && p.ji !== undefined) {
                    setJuliaC({ r: p.jr, i: p.ji });
                  }
                }}
                className="p-2 rounded-xl bg-slate-950/60 hover:bg-slate-950 border border-slate-800/80 hover:border-slate-700 text-left transition-all cursor-pointer flex items-center justify-between"
              >
                <span className="text-xs font-medium text-slate-300 hover:text-cyan-400">
                  {p.name}
                </span>
                <span className="text-[10px] text-slate-500 font-mono">
                  {p.zoom}x
                </span>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
