import React, { useState, useEffect, useRef } from 'react';
import { 
  RotateCcw, 
  Trash2, 
  Copy, 
  Check, 
  Star, 
  Download, 
  ChevronDown, 
  ChevronUp, 
  Sparkles,
  ArrowRight
} from 'lucide-react';
import { AngleMode, NumberFormat, HistoryItem } from '../types';
import { evaluateExpression, formatResult, CONSTANTS } from '../utils/mathEngine';
import { sound } from '../utils/audio';

export const ScientificCalc: React.FC = () => {
  const [expression, setExpression] = useState<string>('');
  const [livePreview, setLivePreview] = useState<string>('');
  const [previewError, setPreviewError] = useState<boolean>(false);
  const [angleMode, setAngleMode] = useState<AngleMode>('DEG');
  const [numberFormat, setNumberFormat] = useState<NumberFormat>('standard');
  const [precision, setPrecision] = useState<number>(10);
  const [memory, setMemory] = useState<number>(0);
  const [hasMemory, setHasMemory] = useState<boolean>(false);
  const [lastAnswer, setLastAnswer] = useState<number>(0);
  const [showExtendedFns, setShowExtendedFns] = useState<boolean>(false);
  const [showHistory, setShowHistory] = useState<boolean>(true);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // History state with localStorage persistence
  const [history, setHistory] = useState<HistoryItem[]>(() => {
    try {
      const saved = localStorage.getItem('omnicalc_history');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    localStorage.setItem('omnicalc_history', JSON.stringify(history));
  }, [history]);

  // Live evaluation preview
  useEffect(() => {
    if (!expression.trim()) {
      setLivePreview('');
      setPreviewError(false);
      return;
    }

    try {
      const val = evaluateExpression(expression, {
        angleMode,
        variables: { ans: lastAnswer },
      });
      if (Number.isFinite(val) && !Number.isNaN(val)) {
        setLivePreview(formatResult(val, numberFormat, precision));
        setPreviewError(false);
      } else {
        setLivePreview('');
      }
    } catch {
      // Incomplete or syntactically building formula, no big error
      setLivePreview('');
      setPreviewError(false);
    }
  }, [expression, angleMode, numberFormat, precision, lastAnswer]);

  const insertText = (str: string) => {
    sound.playClick();
    setExpression(prev => prev + str);
    if (inputRef.current) {
      inputRef.current.focus();
    }
  };

  const handleClear = () => {
    sound.playClear();
    setExpression('');
    setLivePreview('');
  };

  const handleBackspace = () => {
    sound.playClick();
    setExpression(prev => prev.slice(0, -1));
  };

  const handleCalculate = () => {
    if (!expression.trim()) return;
    try {
      const val = evaluateExpression(expression, {
        angleMode,
        variables: { ans: lastAnswer },
      });

      if (Number.isNaN(val) || !Number.isFinite(val)) {
        throw new Error('Calculation resulted in undefined/infinity');
      }

      sound.playEqual();
      const formatted = formatResult(val, numberFormat, precision);
      setLastAnswer(val);

      const newItem: HistoryItem = {
        id: Date.now().toString(),
        expression,
        result: formatted,
        timestamp: Date.now(),
        mode: 'scientific',
      };

      setHistory(prev => [newItem, ...prev.slice(0, 49)]);
      setExpression(formatted);
    } catch (err: unknown) {
      sound.playError();
      const message = err instanceof Error ? err.message : 'Invalid Expression';
      setLivePreview(`Error: ${message}`);
      setPreviewError(true);
    }
  };

  // Keyboard binding
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't intercept when focusing other input elements outside calculator
      if (document.activeElement && document.activeElement.tagName === 'INPUT' && document.activeElement !== inputRef.current) {
        return;
      }

      if (e.key === 'Enter') {
        e.preventDefault();
        handleCalculate();
      } else if (e.key === 'Escape') {
        e.preventDefault();
        handleClear();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [expression, angleMode, numberFormat, precision, lastAnswer]);

  const handleMemory = (action: 'MC' | 'MR' | 'M+' | 'M-' | 'MS') => {
    sound.playOperator();
    const currentVal = evaluateExpression(expression || String(lastAnswer), {
      angleMode,
      variables: { ans: lastAnswer },
    });

    if (isNaN(currentVal)) return;

    switch (action) {
      case 'MC':
        setMemory(0);
        setHasMemory(false);
        break;
      case 'MR':
        insertText(String(memory));
        break;
      case 'MS':
        setMemory(currentVal);
        setHasMemory(true);
        break;
      case 'M+':
        setMemory(m => m + currentVal);
        setHasMemory(true);
        break;
      case 'M-':
        setMemory(m => m - currentVal);
        setHasMemory(true);
        break;
    }
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 1500);
  };

  const clearHistory = () => {
    sound.playClear();
    setHistory([]);
  };

  const exportHistory = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(history, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `omnicalc-history-${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  return (
    <div className="max-w-7xl mx-auto p-3 sm:p-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
      {/* Main Calculator Engine */}
      <div className="lg:col-span-8 flex flex-col space-y-4">
        {/* Top Control Bar: Angle Mode, Precision, Format */}
        <div className="flex flex-wrap items-center justify-between gap-2 p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-xs">
          <div className="flex items-center space-x-1.5">
            <span className="text-slate-400 font-medium">Angle:</span>
            {(['DEG', 'RAD', 'GRAD'] as AngleMode[]).map(mode => (
              <button
                key={mode}
                onClick={() => {
                  sound.playClick();
                  setAngleMode(mode);
                }}
                className={`px-2.5 py-1 rounded font-semibold transition-all cursor-pointer ${
                  angleMode === mode
                    ? 'bg-cyan-500 text-slate-950 shadow-sm shadow-cyan-500/30'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                }`}
              >
                {mode}
              </button>
            ))}
          </div>

          <div className="flex items-center space-x-2">
            <span className="text-slate-400 font-medium hidden sm:inline">Format:</span>
            <div className="flex rounded-lg bg-slate-950 p-0.5 border border-slate-800">
              {(
                [
                  { id: 'standard', label: 'Std' },
                  { id: 'scientific', label: 'Sci' },
                  { id: 'engineering', label: 'Eng' },
                  { id: 'fraction', label: 'a/b' },
                ] as { id: NumberFormat; label: string }[]
              ).map(fmt => (
                <button
                  key={fmt.id}
                  onClick={() => {
                    sound.playClick();
                    setNumberFormat(fmt.id);
                  }}
                  className={`px-2 py-0.5 rounded text-[11px] font-medium transition-all cursor-pointer ${
                    numberFormat === fmt.id
                      ? 'bg-indigo-600 text-white shadow-sm'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {fmt.label}
                </button>
              ))}
            </div>

            <div className="flex items-center space-x-1 text-slate-400 text-[11px]">
              <span>Dec:</span>
              <select
                value={precision}
                onChange={e => setPrecision(Number(e.target.value))}
                className="bg-slate-950 border border-slate-800 rounded px-1.5 py-0.5 text-cyan-400 outline-none cursor-pointer"
              >
                <option value={4}>4</option>
                <option value={8}>8</option>
                <option value={10}>10</option>
                <option value={14}>14</option>
              </select>
            </div>
          </div>
        </div>

        {/* Display Screen */}
        <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-b from-slate-900 to-slate-950 border border-slate-800 shadow-2xl relative overflow-hidden">
          <div className="flex items-center justify-between text-xs text-slate-400 font-mono mb-2">
            <div className="flex items-center space-x-2">
              <span className="text-cyan-400 font-bold">{angleMode}</span>
              <span>•</span>
              <span className="uppercase text-indigo-400">{numberFormat}</span>
              {hasMemory && (
                <>
                  <span>•</span>
                  <span className="px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-400 text-[10px] font-bold">
                    M: {memory}
                  </span>
                </>
              )}
            </div>
            {lastAnswer !== 0 && (
              <span className="text-slate-500 truncate max-w-[200px]">
                Ans = {lastAnswer}
              </span>
            )}
          </div>

          {/* Formula input */}
          <div className="relative">
            <input
              ref={inputRef}
              type="text"
              value={expression}
              onChange={e => setExpression(e.target.value)}
              placeholder="0"
              className="w-full bg-transparent text-right font-mono text-2xl sm:text-3xl text-white outline-none tracking-wider placeholder:text-slate-700"
            />
          </div>

          {/* Live Preview / Error */}
          <div className="h-7 mt-2 flex items-center justify-end font-mono text-base sm:text-lg">
            {livePreview && (
              <span className={`flex items-center gap-1.5 ${previewError ? 'text-rose-400 text-sm' : 'text-cyan-400/90 font-medium'}`}>
                {!previewError && <ArrowRight className="w-3.5 h-3.5 text-cyan-500" />}
                {livePreview}
              </span>
            )}
          </div>
        </div>

        {/* Memory Bar */}
        <div className="grid grid-cols-5 gap-1.5 text-xs font-mono font-bold">
          {(['MC', 'MR', 'M+', 'M-', 'MS'] as const).map(op => (
            <button
              key={op}
              onClick={() => handleMemory(op)}
              className="py-1.5 rounded-lg bg-slate-900/80 hover:bg-slate-800 text-slate-400 hover:text-cyan-300 border border-slate-800/80 transition-all cursor-pointer"
            >
              {op}
            </button>
          ))}
        </div>

        {/* Constants Quick Bar */}
        <div className="flex items-center space-x-1.5 overflow-x-auto pb-1 text-xs font-mono">
          <span className="text-slate-500 text-[11px] uppercase mr-1">Const:</span>
          {Object.entries(CONSTANTS).map(([key, data]) => (
            <button
              key={key}
              onClick={() => insertText(key)}
              title={`${data.desc} = ${data.value}`}
              className="px-2 py-1 rounded bg-slate-900 hover:bg-cyan-950/40 text-cyan-300 border border-slate-800 hover:border-cyan-500/40 transition-all cursor-pointer whitespace-nowrap"
            >
              {data.symbol}
            </button>
          ))}
          <button
            onClick={() => insertText('ans')}
            className="px-2 py-1 rounded bg-slate-900 hover:bg-indigo-950/40 text-indigo-300 border border-slate-800 transition-all cursor-pointer"
          >
            ans
          </button>
        </div>

        {/* Keypad Layout */}
        <div className="grid grid-cols-4 sm:grid-cols-5 gap-2 font-mono text-sm sm:text-base">
          {/* Extended toggle on small screens */}
          <div className="col-span-4 sm:col-span-5 flex justify-between items-center sm:hidden mb-1">
            <button
              onClick={() => setShowExtendedFns(!showExtendedFns)}
              className="flex items-center space-x-1 text-xs text-cyan-400 py-1"
            >
              <span>{showExtendedFns ? 'Hide Advanced Functions' : 'Show Advanced Functions'}</span>
              {showExtendedFns ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
            </button>
          </div>

          {/* Scientific Functions */}
          <div className={`${showExtendedFns ? 'grid' : 'hidden'} sm:grid grid-cols-4 sm:grid-cols-5 col-span-4 sm:col-span-5 gap-2`}>
            <button onClick={() => insertText('sin(')} className="calc-fn-btn">sin</button>
            <button onClick={() => insertText('cos(')} className="calc-fn-btn">cos</button>
            <button onClick={() => insertText('tan(')} className="calc-fn-btn">tan</button>
            <button onClick={() => insertText('asin(')} className="calc-fn-btn">asin</button>
            <button onClick={() => insertText('acos(')} className="calc-fn-btn">acos</button>

            <button onClick={() => insertText('ln(')} className="calc-fn-btn">ln</button>
            <button onClick={() => insertText('log(')} className="calc-fn-btn">log₁₀</button>
            <button onClick={() => insertText('log2(')} className="calc-fn-btn">log₂</button>
            <button onClick={() => insertText('sqrt(')} className="calc-fn-btn">√</button>
            <button onClick={() => insertText('cbrt(')} className="calc-fn-btn">∛</button>

            <button onClick={() => insertText('^')} className="calc-fn-btn">xʸ</button>
            <button onClick={() => insertText('^2')} className="calc-fn-btn">x²</button>
            <button onClick={() => insertText('exp(')} className="calc-fn-btn">eˣ</button>
            <button onClick={() => insertText('!')} className="calc-fn-btn">n!</button>
            <button onClick={() => insertText('%')} className="calc-fn-btn">mod</button>

            <button onClick={() => insertText('nCr(')} className="calc-fn-btn">nCr</button>
            <button onClick={() => insertText('nPr(')} className="calc-fn-btn">nPr</button>
            <button onClick={() => insertText('gcd(')} className="calc-fn-btn">gcd</button>
            <button onClick={() => insertText('abs(')} className="calc-fn-btn">|x|</button>
            <button onClick={() => insertText(',')} className="calc-fn-btn">,</button>
          </div>

          {/* Primary Numeric & Operator Keypad */}
          <button onClick={handleClear} className="calc-btn text-rose-400 bg-rose-950/20 border-rose-900/40 hover:bg-rose-900/40 font-bold">
            AC
          </button>
          <button onClick={handleBackspace} className="calc-btn text-amber-400 bg-amber-950/20 border-amber-900/40 hover:bg-amber-900/40">
            DEL
          </button>
          <button onClick={() => insertText('(')} className="calc-btn text-slate-300 bg-slate-900">
            (
          </button>
          <button onClick={() => insertText(')')} className="calc-btn text-slate-300 bg-slate-900">
            )
          </button>
          <button onClick={() => insertText('/')} className="calc-btn text-cyan-400 bg-cyan-950/30 border-cyan-800/40 hover:bg-cyan-900/40">
            ÷
          </button>

          <button onClick={() => insertText('7')} className="calc-num-btn">7</button>
          <button onClick={() => insertText('8')} className="calc-num-btn">8</button>
          <button onClick={() => insertText('9')} className="calc-num-btn">9</button>
          <button onClick={() => insertText('*')} className="calc-btn text-cyan-400 bg-cyan-950/30 border-cyan-800/40 hover:bg-cyan-900/40">
            ×
          </button>
          <button onClick={() => insertText('pi')} className="calc-btn text-indigo-300 bg-slate-900 hidden sm:block">
            π
          </button>

          <button onClick={() => insertText('4')} className="calc-num-btn">4</button>
          <button onClick={() => insertText('5')} className="calc-num-btn">5</button>
          <button onClick={() => insertText('6')} className="calc-num-btn">6</button>
          <button onClick={() => insertText('-')} className="calc-btn text-cyan-400 bg-cyan-950/30 border-cyan-800/40 hover:bg-cyan-900/40">
            −
          </button>
          <button onClick={() => insertText('e')} className="calc-btn text-indigo-300 bg-slate-900 hidden sm:block">
            e
          </button>

          <button onClick={() => insertText('1')} className="calc-num-btn">1</button>
          <button onClick={() => insertText('2')} className="calc-num-btn">2</button>
          <button onClick={() => insertText('3')} className="calc-num-btn">3</button>
          <button onClick={() => insertText('+')} className="calc-btn text-cyan-400 bg-cyan-950/30 border-cyan-800/40 hover:bg-cyan-900/40">
            +
          </button>
          <button onClick={() => insertText('^')} className="calc-btn text-indigo-300 bg-slate-900 hidden sm:block">
            ^
          </button>

          <button onClick={() => insertText('0')} className="calc-num-btn col-span-2">0</button>
          <button onClick={() => insertText('.')} className="calc-num-btn font-bold">.</button>
          <button
            onClick={handleCalculate}
            className="calc-btn text-slate-950 bg-gradient-to-r from-cyan-400 to-indigo-400 hover:from-cyan-300 hover:to-indigo-300 font-black shadow-lg shadow-cyan-500/20 col-span-1 sm:col-span-2 text-xl"
          >
            =
          </button>
        </div>
      </div>

      {/* History & Memory Inspector Panel */}
      <div className="lg:col-span-4 flex flex-col space-y-4">
        <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 flex flex-col h-[520px]">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center space-x-2">
              <Sparkles className="w-4 h-4 text-cyan-400" />
              <h2 className="font-semibold text-sm text-slate-200">Calculation Tape</h2>
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-400 font-mono">
                {history.length}
              </span>
            </div>

            <div className="flex items-center space-x-1">
              {history.length > 0 && (
                <>
                  <button
                    onClick={exportHistory}
                    className="p-1.5 rounded hover:bg-slate-800 text-slate-400 hover:text-cyan-400 transition-colors"
                    title="Export history JSON"
                  >
                    <Download className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={clearHistory}
                    className="p-1.5 rounded hover:bg-slate-800 text-slate-400 hover:text-rose-400 transition-colors"
                    title="Clear history"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </>
              )}
            </div>
          </div>

          {/* History List */}
          <div className="flex-1 overflow-y-auto space-y-2.5 py-3 pr-1">
            {history.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center p-6 text-slate-500">
                <RotateCcw className="w-8 h-8 mb-2 opacity-30" />
                <p className="text-xs">No calculations yet</p>
                <p className="text-[11px] text-slate-600 mt-1">Calculations will be saved automatically</p>
              </div>
            ) : (
              history.map(item => (
                <div
                  key={item.id}
                  className="p-2.5 rounded-xl bg-slate-950/70 hover:bg-slate-950 border border-slate-800/80 transition-all group"
                >
                  <div className="flex items-center justify-between text-[11px] text-slate-500 font-mono">
                    <span className="truncate max-w-[200px]">{item.expression}</span>
                    <button
                      onClick={() => copyToClipboard(item.result, item.id)}
                      className="opacity-0 group-hover:opacity-100 p-1 rounded hover:bg-slate-800 text-slate-400 transition-opacity"
                      title="Copy result"
                    >
                      {copiedId === item.id ? (
                        <Check className="w-3 h-3 text-emerald-400" />
                      ) : (
                        <Copy className="w-3 h-3" />
                      )}
                    </button>
                  </div>
                  <div className="mt-1 flex items-center justify-between">
                    <button
                      onClick={() => {
                        sound.playClick();
                        setExpression(item.result);
                      }}
                      className="text-sm font-mono font-bold text-cyan-300 hover:text-cyan-200 text-left truncate cursor-pointer"
                      title="Insert into calculator"
                    >
                      = {item.result}
                    </button>
                    <button
                      onClick={() => {
                        sound.playClick();
                        setExpression(item.expression);
                      }}
                      className="text-[10px] text-indigo-400 hover:text-indigo-300 uppercase tracking-wider font-semibold opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      Replay
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Quick variable cheat sheet */}
          <div className="pt-2 border-t border-slate-800/80 text-[11px] text-slate-500 flex justify-between items-center">
            <span>Ans = previous result</span>
            <span className="font-mono text-cyan-500">π ≈ 3.14159</span>
          </div>
        </div>
      </div>
    </div>
  );
};
