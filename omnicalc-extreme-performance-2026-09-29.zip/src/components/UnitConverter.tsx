import React, { useState } from 'react';
import { 
  Ruler, 
  Scale, 
  Thermometer, 
  Gauge, 
  HardDrive, 
  Zap, 
  Compass, 
  Square, 
  Box, 
  ArrowLeftRight, 
  Copy, 
  Check,
  Search
} from 'lucide-react';
import { UNIT_CATEGORIES, convertUnits } from '../utils/unitEngine';
import { sound } from '../utils/audio';

const iconMap: Record<string, React.FC<{ className?: string }>> = {
  Ruler,
  Scale,
  Thermometer,
  Gauge,
  HardDrive,
  Zap,
  Compass,
  Square,
  Box,
};

export const UnitConverter: React.FC = () => {
  const [selectedCatId, setSelectedCatId] = useState<string>('length');
  const [inputValue, setInputValue] = useState<number>(1);
  const [fromUnitId, setFromUnitId] = useState<string>('m');
  const [toUnitId, setToUnitId] = useState<string>('ft');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [searchFilter, setSearchFilter] = useState<string>('');

  const currentCategory = UNIT_CATEGORIES.find(c => c.id === selectedCatId) || UNIT_CATEGORIES[0];

  const handleCategoryChange = (catId: string) => {
    sound.playClick();
    setSelectedCatId(catId);
    const cat = UNIT_CATEGORIES.find(c => c.id === catId);
    if (cat && cat.units.length >= 2) {
      setFromUnitId(cat.units[0].id);
      setToUnitId(cat.units[1].id);
    }
  };

  const handleSwap = () => {
    sound.playClick();
    const temp = fromUnitId;
    setFromUnitId(toUnitId);
    setToUnitId(temp);
  };

  const convertedValue = convertUnits(inputValue, fromUnitId, toUnitId, currentCategory.id);

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 1500);
  };

  // Filtered unit matrix
  const filteredUnits = currentCategory.units.filter(u =>
    u.name.toLowerCase().includes(searchFilter.toLowerCase()) ||
    u.symbol.toLowerCase().includes(searchFilter.toLowerCase())
  );

  return (
    <div className="max-w-7xl mx-auto p-3 sm:p-6 space-y-6">
      {/* Category Pills Bar */}
      <div className="flex items-center space-x-2 overflow-x-auto pb-2 scrollbar-none">
        {UNIT_CATEGORIES.map(cat => {
          const Icon = iconMap[cat.iconName] || Ruler;
          const isActive = cat.id === selectedCatId;
          return (
            <button
              key={cat.id}
              onClick={() => handleCategoryChange(cat.id)}
              className={`flex items-center space-x-2 px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
                isActive
                  ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                  : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-slate-200 hover:bg-slate-800'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{cat.name}</span>
            </button>
          );
        })}
      </div>

      {/* Main Conversion Cards */}
      <div className="grid grid-cols-1 md:grid-cols-11 gap-4 items-center">
        {/* From Box */}
        <div className="md:col-span-5 p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3 shadow-xl">
          <label className="text-xs text-slate-500 uppercase font-mono tracking-wider">
            From
          </label>
          <input
            type="number"
            value={inputValue}
            onChange={e => setInputValue(Number(e.target.value))}
            className="w-full bg-slate-950 px-4 py-3 rounded-xl border border-slate-800 text-2xl font-mono text-white focus:border-cyan-500 outline-none"
          />
          <select
            value={fromUnitId}
            onChange={e => setFromUnitId(e.target.value)}
            className="w-full bg-slate-950 px-3 py-2.5 rounded-xl border border-slate-800 text-sm font-medium text-cyan-300 outline-none cursor-pointer"
          >
            {currentCategory.units.map(u => (
              <option key={u.id} value={u.id}>
                {u.name} ({u.symbol})
              </option>
            ))}
          </select>
        </div>

        {/* Swap Button */}
        <div className="md:col-span-1 flex justify-center">
          <button
            onClick={handleSwap}
            className="p-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-400 transition-transform active:rotate-180 cursor-pointer shadow-lg"
            title="Swap Units"
          >
            <ArrowLeftRight className="w-5 h-5" />
          </button>
        </div>

        {/* To Box */}
        <div className="md:col-span-5 p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3 shadow-xl relative group">
          <div className="flex items-center justify-between">
            <label className="text-xs text-slate-500 uppercase font-mono tracking-wider">
              Result (To)
            </label>
            <button
              onClick={() => copyToClipboard(convertedValue.toString(), 'main-res')}
              className="p-1 rounded hover:bg-slate-800 text-slate-500 hover:text-cyan-400 transition-colors"
              title="Copy"
            >
              {copiedId === 'main-res' ? (
                <Check className="w-4 h-4 text-emerald-400" />
              ) : (
                <Copy className="w-4 h-4" />
              )}
            </button>
          </div>
          <div className="w-full bg-slate-950 px-4 py-3 rounded-xl border border-slate-800 text-2xl font-mono text-cyan-400 font-bold overflow-x-auto whitespace-nowrap">
            {convertedValue.toLocaleString('en-US', { maximumFractionDigits: 8 })}
          </div>
          <select
            value={toUnitId}
            onChange={e => setToUnitId(e.target.value)}
            className="w-full bg-slate-950 px-3 py-2.5 rounded-xl border border-slate-800 text-sm font-medium text-cyan-300 outline-none cursor-pointer"
          >
            {currentCategory.units.map(u => (
              <option key={u.id} value={u.id}>
                {u.name} ({u.symbol})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Simultaneous All-Unit Real-time Matrix */}
      <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
          <div>
            <h3 className="font-bold text-sm text-slate-200">
              Simultaneous Multi-Unit Matrix
            </h3>
            <p className="text-xs text-slate-400">
              Live conversions for {inputValue} {currentCategory.units.find(u => u.id === fromUnitId)?.symbol}
            </p>
          </div>

          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchFilter}
              onChange={e => setSearchFilter(e.target.value)}
              placeholder="Search units..."
              className="pl-8 pr-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-200 outline-none focus:border-cyan-500"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
          {filteredUnits.map(unit => {
            const val = convertUnits(inputValue, fromUnitId, unit.id, currentCategory.id);
            const formatted = val.toLocaleString('en-US', { maximumFractionDigits: 6 });
            const isSource = unit.id === fromUnitId;

            return (
              <div
                key={unit.id}
                onClick={() => {
                  sound.playClick();
                  setToUnitId(unit.id);
                }}
                className={`p-3 rounded-xl border flex items-center justify-between transition-all cursor-pointer ${
                  isSource
                    ? 'bg-cyan-950/20 border-cyan-500/40'
                    : 'bg-slate-950/60 border-slate-800/80 hover:border-slate-700'
                }`}
              >
                <div className="truncate pr-2">
                  <div className="text-xs text-slate-400 truncate">
                    {unit.name} ({unit.symbol})
                  </div>
                  <div className="font-mono text-sm font-bold text-white truncate mt-0.5">
                    {formatted} {unit.symbol}
                  </div>
                </div>

                <button
                  onClick={e => {
                    e.stopPropagation();
                    copyToClipboard(val.toString(), unit.id);
                  }}
                  className="p-1.5 rounded hover:bg-slate-800 text-slate-500 hover:text-cyan-400 transition-colors shrink-0"
                  title="Copy"
                >
                  {copiedId === unit.id ? (
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                  ) : (
                    <Copy className="w-3.5 h-3.5" />
                  )}
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
