import React, { useState } from 'react';
import { 
  X, 
  Download, 
  Smartphone, 
  Monitor, 
  Terminal, 
  CheckCircle2, 
  ArrowRight, 
  Sparkles, 
  Share2, 
  FolderArchive,
  Loader2
} from 'lucide-react';
import { downloadProjectZip } from '../utils/sourceZip';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { sound } from '../utils/audio';

interface DownloadModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DownloadModal: React.FC<DownloadModalProps> = ({ isOpen, onClose }) => {
  const [isZipping, setIsZipping] = useState(false);
  const [zipSuccess, setZipSuccess] = useState(false);
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();

  if (!isOpen) return null;

  const handleDownloadZip = async () => {
    sound.playClick();
    setIsZipping(true);
    setZipSuccess(false);
    try {
      await downloadProjectZip();
      setZipSuccess(true);
      sound.playEqual();
      setTimeout(() => setZipSuccess(false), 3000);
    } catch (err) {
      console.error(err);
      sound.playError();
    } finally {
      setIsZipping(false);
    }
  };

  const handlePWAInstall = async () => {
    sound.playClick();
    const success = await install();
    if (success) {
      sound.playEqual();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-fadeIn">
      <div className="w-full max-w-xl rounded-3xl bg-slate-900 border border-slate-800 shadow-2xl p-6 sm:p-7 space-y-6 max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 rounded-2xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/30">
              <Download className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-lg text-white">Download & Install OmniCalc</h3>
              <p className="text-xs text-slate-400">
                ডাউনলোড ও ডিভাইসে ইনস্টল করার উপায়
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="p-2 rounded-xl hover:bg-slate-800 text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Method 1: Download Full Source Code ZIP */}
        <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2.5">
              <FolderArchive className="w-5 h-5 text-cyan-400" />
              <div>
                <h4 className="font-bold text-sm text-slate-200">
                  Option 1: Download Source Code (.ZIP)
                </h4>
                <p className="text-xs text-slate-400">
                  সম্পূর্ণ প্রজেক্ট সোর্স কোড (React + TypeScript + Vite) ডাউনলোড করুন
                </p>
              </div>
            </div>
          </div>

          <p className="text-xs text-slate-400 leading-relaxed">
            এটি ক্লিক করলে সম্পূর্ণ প্রজেক্টের সব ফাইল (Components, Algorithms, Benchmarks, Styles, Config) একটি জিপ ফাইল হিসেবে সরাসরি আপনার ডিভাইসে ডাউনলোড হয়ে যাবে।
          </p>

          <button
            onClick={handleDownloadZip}
            disabled={isZipping}
            className={`w-full py-3 px-4 rounded-xl font-bold text-sm flex items-center justify-center space-x-2 transition-all cursor-pointer ${
              zipSuccess
                ? 'bg-emerald-500 text-slate-950'
                : 'bg-cyan-500 hover:bg-cyan-400 text-slate-950 shadow-lg shadow-cyan-500/20'
            }`}
          >
            {isZipping ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Creating Project ZIP...</span>
              </>
            ) : zipSuccess ? (
              <>
                <CheckCircle2 className="w-4 h-4" />
                <span>Downloaded Successfully!</span>
              </>
            ) : (
              <>
                <Download className="w-4 h-4" />
                <span>Download omnicalc-extreme-performance.zip</span>
              </>
            )}
          </button>
        </div>

        {/* Method 2: Install as Native App (PWA on Android / Desktop) */}
        <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
          <div className="flex items-center space-x-2.5">
            <Smartphone className="w-5 h-5 text-indigo-400" />
            <div>
              <h4 className="font-bold text-sm text-slate-200">
                Option 2: Install on Mobile / PC as App
              </h4>
              <p className="text-xs text-slate-400">
                ফোন বা কম্পিউটারে অ্যাপ হিসেবে ইনস্টল করুন (Offline Supported)
              </p>
            </div>
          </div>

          {isInstalled ? (
            <div className="p-3 rounded-xl bg-emerald-950/20 border border-emerald-500/30 flex items-center space-x-2 text-xs text-emerald-400">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>OmniCalc is already installed and running as a standalone app!</span>
            </div>
          ) : isInstallable ? (
            <button
              onClick={handlePWAInstall}
              className="w-full py-3 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-sm flex items-center justify-center space-x-2 transition-all cursor-pointer shadow-lg shadow-indigo-600/20"
            >
              <Smartphone className="w-4 h-4" />
              <span>Install OmniCalc App (1-Click)</span>
            </button>
          ) : isIOS ? (
            <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-2 text-xs text-slate-300">
              <div className="font-semibold text-cyan-400">iPhone / iPad এ যেভাবে ইনস্টল করবেন:</div>
              <ol className="list-decimal pl-4 space-y-1 text-slate-400">
                <li>Safari ব্রাউজারে নিচে <strong>Share (শেয়ার)</strong> আইকনে চাপ দিন।</li>
                <li>নিচে স্ক্রোল করে <strong>&quot;Add to Home Screen&quot; (হোম স্ক্রিনে যোগ করুন)</strong> সিলেক্ট করুন।</li>
              </ol>
            </div>
          ) : (
            <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-2 text-xs text-slate-300">
              <div className="font-semibold text-cyan-400">Android / Chrome ব্রাউজার থেকে ইনস্টল করার নিয়ম:</div>
              <ol className="list-decimal pl-4 space-y-1 text-slate-400">
                <li>Chrome ব্রাউজারের উপরে ডানদিকের <strong>তিনটি ডট (Menu ⋮)</strong> এ চাপ দিন।</li>
                <li><strong>&quot;Install app&quot;</strong> অথবা <strong>&quot;Add to Home screen&quot;</strong> চাপুন।</li>
                <li>অ্যাপটি আপনার ফোনের হোম স্ক্রিনে ইনস্টল হয়ে যাবে এবং অফলাইনেও চলবে।</li>
              </ol>
            </div>
          )}
        </div>

        {/* Method 3: Run Locally (Developers) */}
        <div className="p-4 rounded-2xl bg-slate-950/70 border border-slate-800/80 space-y-2">
          <div className="flex items-center space-x-2 text-xs font-semibold text-slate-300">
            <Terminal className="w-4 h-4 text-cyan-400" />
            <span>How to run after downloading ZIP:</span>
          </div>
          <div className="p-2.5 rounded-xl bg-slate-900 font-mono text-[11px] text-cyan-300 space-y-1 border border-slate-800">
            <div>1. unzip omnicalc-extreme-performance.zip</div>
            <div>2. npm install</div>
            <div>3. npm run dev</div>
          </div>
        </div>

        {/* Close Button */}
        <div className="flex justify-end pt-2">
          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="px-5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
