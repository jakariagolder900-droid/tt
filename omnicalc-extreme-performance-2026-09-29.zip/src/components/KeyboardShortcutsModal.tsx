import React from 'react';
import { X, Keyboard, Zap, Sparkles } from 'lucide-react';
import { sound } from '../utils/audio';

interface KeyboardShortcutsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const KeyboardShortcutsModal: React.FC<KeyboardShortcutsModalProps> = ({
  isOpen,
  onClose,
}) => {
  if (!isOpen) return null;

  const shortcuts = [
    { key: '0 - 9', desc: 'Input numeric digits' },
    { key: '+ - * /', desc: 'Basic arithmetic operators' },
    { key: '^', desc: 'Exponent / Power' },
    { key: '%', desc: 'Modulo operator' },
    { key: 'Enter / =', desc: 'Evaluate expression' },
    { key: 'Escape', desc: 'Clear expression (All Clear / AC)' },
    { key: 'Backspace', desc: 'Delete previous character' },
    { key: '( and )', desc: 'Group expressions with parentheses' },
    { key: 'pi / e', desc: 'Insert mathematical constants π and e' },
    { key: 'ans', desc: 'Reference the previous computed result' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fadeIn">
      <div className="w-full max-w-lg rounded-3xl bg-slate-900 border border-slate-800 shadow-2xl p-6 space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center space-x-2.5">
            <div className="p-2 rounded-xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/30">
              <Keyboard className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base text-white">Keyboard Shortcuts & Guide</h3>
              <p className="text-xs text-slate-400">OmniCalc Extreme Performance Controls</p>
            </div>
          </div>
          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="p-2 rounded-xl hover:bg-slate-800 text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
          {shortcuts.map(s => (
            <div
              key={s.key}
              className="p-2.5 rounded-xl bg-slate-950/70 border border-slate-800/80 flex items-center justify-between"
            >
              <kbd className="px-2 py-1 rounded bg-slate-900 border border-slate-700 font-mono text-cyan-400 font-bold text-[11px]">
                {s.key}
              </kbd>
              <span className="text-slate-400 text-right pl-2">{s.desc}</span>
            </div>
          ))}
        </div>

        <div className="p-3.5 rounded-2xl bg-cyan-950/20 border border-cyan-500/30 flex items-start space-x-3 text-xs text-cyan-300">
          <Zap className="w-4 h-4 shrink-0 text-cyan-400 mt-0.5" />
          <div>
            <span className="font-bold">Hardware Performance Note:</span> The Extreme Benchmark suite stresses your CPU through intensive Float64 matrix operations and stochastic simulations. For maximum scores, ensure your device is not in battery saver mode.
          </div>
        </div>

        <div className="flex justify-end pt-2">
          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="px-5 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs transition-colors cursor-pointer"
          >
            Got it
          </button>
        </div>
      </div>
    </div>
  );
};
