import React, { useState } from 'react';
import { 
  Zap, 
  Play, 
  RotateCcw, 
  Award, 
  Cpu, 
  HardDrive, 
  Activity, 
  CheckCircle2, 
  ArrowUpRight, 
  Share2, 
  Download,
  ShieldCheck,
  Flame
} from 'lucide-react';
import { runFullBenchmarkSuite, BenchmarkReport } from '../utils/benchmarkEngine';
import { sound } from '../utils/audio';

export const BenchmarkSuite: React.FC = () => {
  const [isRunning, setIsRunning] = useState(false);
  const [currentTest, setCurrentTest] = useState<string>('');
  const [progress, setProgress] = useState<number>(0);
  const [report, setReport] = useState<BenchmarkReport | null>(null);

  const startBenchmark = async () => {
    sound.playOperator();
    setIsRunning(true);
    setProgress(0);
    setCurrentTest('Initializing Hardware Timers...');

    try {
      const res = await runFullBenchmarkSuite((testName, percent) => {
        setCurrentTest(testName);
        setProgress(percent);
      });
      setReport(res);
      sound.playEqual();
    } catch (err) {
      console.error(err);
      sound.playError();
    } finally {
      setIsRunning(false);
    }
  };

  const exportReport = () => {
    if (!report) return;
    const text = `=== OMNICALC EXTREME PERFORMANCE BENCHMARK REPORT ===
Date: ${new Date(report.timestamp).toLocaleString()}
Total Score: ${report.totalScore} (${report.hardwareTier})
Total Execution Time: ${report.totalDurationMs} ms
Logical CPU Cores: ${report.deviceInfo.logicalCores}
Platform: ${report.deviceInfo.platform}
Memory: ${report.deviceInfo.memoryEstimate || 'N/A'}

--- METRICS BREAKDOWN ---
${report.metrics
  .map(
    m =>
      `• ${m.name} [${m.category}]
   Throughput: ${m.opsValue} ${m.unit} | Time: ${m.durationMs}ms | Score: ${m.score} (${m.ratingText})
   Details: ${m.details}`
  )
  .join('\n\n')}
=====================================================`;

    const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `omnicalc-benchmark-${Date.now()}.txt`;
    link.click();
    URL.revokeObjectURL(url);
  };

  // Hardware comparison baselines
  const baselines = [
    { name: 'Apple M3 Max (Silicon)', score: 3850, tier: 'God Tier' },
    { name: 'Intel Core i9-14900K (Desktop)', score: 3600, tier: 'God Tier' },
    { name: 'AMD Ryzen 9 7950X', score: 3450, tier: 'God Tier' },
    { name: 'Snapdragon 8 Gen 3 (Mobile Flagship)', score: 2600, tier: 'Tier S' },
    { name: 'Intel Core i7-12700H (Laptop)', score: 2200, tier: 'Tier A' },
    { name: 'Mainstream Mobile / Tablet', score: 1100, tier: 'Tier B' },
  ];

  return (
    <div className="max-w-7xl mx-auto p-3 sm:p-6 space-y-6">
      {/* Hero Banner: Stress Test Launcher */}
      <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-br from-slate-900 via-indigo-950/40 to-slate-950 border border-slate-800 shadow-2xl relative overflow-hidden">
        {/* Decorative background glow */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-violet-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-3 max-w-2xl">
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 text-xs font-bold tracking-wide uppercase">
              <Flame className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
              <span>Extreme Performance Benchmark Suite</span>
            </div>
            <h2 className="text-2xl sm:text-4xl font-extrabold text-white tracking-tight">
              Test Peak Hardware Compute & Precision Engine
            </h2>
            <p className="text-sm text-slate-400 leading-relaxed">
              Executes intensive multi-threaded FP operations: Monte Carlo π stochastic simulation, dense Float64 GEMM matrix multiplication, 3M-number prime sieving, Mandelbrot fractal escape stress, and transcendental pipelines.
            </p>

            <div className="flex flex-wrap items-center gap-4 text-xs text-slate-400 font-mono pt-1">
              <div className="flex items-center space-x-1.5">
                <Cpu className="w-4 h-4 text-cyan-400" />
                <span>{navigator.hardwareConcurrency || 4} Logical Cores</span>
              </div>
              <div className="flex items-center space-x-1.5">
                <HardDrive className="w-4 h-4 text-indigo-400" />
                <span>Double-Precision (Float64)</span>
              </div>
              <div className="flex items-center space-x-1.5">
                <Activity className="w-4 h-4 text-emerald-400" />
                <span>Real-Time Performance Counters</span>
              </div>
            </div>
          </div>

          {/* Action Button */}
          <div className="flex flex-col items-center sm:items-end">
            <button
              onClick={startBenchmark}
              disabled={isRunning}
              className={`px-8 py-4 rounded-2xl font-bold text-base flex items-center space-x-3 shadow-xl transition-all cursor-pointer ${
                isRunning
                  ? 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
                  : 'bg-gradient-to-r from-cyan-400 via-indigo-500 to-violet-500 hover:from-cyan-300 hover:to-violet-400 text-slate-950 shadow-cyan-500/25 hover:scale-[1.02] active:scale-[0.98]'
              }`}
            >
              {isRunning ? (
                <>
                  <Activity className="w-5 h-5 animate-spin text-cyan-400" />
                  <span>Stressing Compute Core...</span>
                </>
              ) : (
                <>
                  <Zap className="w-5 h-5 text-slate-950 fill-current" />
                  <span>Run Extreme Benchmark</span>
                </>
              )}
            </button>
            {report && !isRunning && (
              <span className="text-[11px] text-slate-500 mt-2 font-mono">
                Last run: {new Date(report.timestamp).toLocaleTimeString()}
              </span>
            )}
          </div>
        </div>

        {/* Live Progress Bar during run */}
        {isRunning && (
          <div className="mt-6 pt-4 border-t border-slate-800/80 space-y-2">
            <div className="flex justify-between items-center text-xs font-mono">
              <span className="text-cyan-400 font-medium flex items-center gap-2">
                <Activity className="w-3.5 h-3.5 animate-spin" />
                {currentTest}
              </span>
              <span className="text-slate-300">{progress}%</span>
            </div>
            <div className="h-2.5 w-full bg-slate-950 rounded-full overflow-hidden p-0.5 border border-slate-800">
              <div
                className="h-full bg-gradient-to-r from-cyan-400 via-indigo-500 to-violet-400 rounded-full transition-all duration-300 shadow-sm shadow-cyan-400/50"
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>
        )}
      </div>

      {/* Results Section */}
      {report && (
        <div className="space-y-6 animate-fadeIn">
          {/* Top Score Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {/* Total Overall Score */}
            <div className="p-6 rounded-2xl bg-slate-900 border border-cyan-500/30 shadow-lg shadow-cyan-500/5 relative overflow-hidden">
              <div className="text-xs text-slate-400 font-mono uppercase tracking-wider">
                Overall Compute Score
              </div>
              <div className="text-4xl sm:text-5xl font-extrabold font-mono text-cyan-400 mt-2 tracking-tight">
                {report.totalScore.toLocaleString()}
              </div>
              <div className="mt-2 inline-flex items-center space-x-1 text-xs font-bold px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>{report.hardwareTier}</span>
              </div>
            </div>

            {/* Matrix FLOPS */}
            <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800">
              <div className="text-xs text-slate-400 font-mono uppercase tracking-wider">
                Peak Linear FLOPS
              </div>
              <div className="text-3xl font-extrabold font-mono text-indigo-400 mt-2">
                {report.metrics.find(m => m.id === 'matrix-gemm')?.opsValue}{' '}
                <span className="text-sm font-normal text-slate-400">GFLOPS</span>
              </div>
              <p className="text-xs text-slate-500 mt-2">
                Float64 GEMM matrix multiplication peak
              </p>
            </div>

            {/* Prime Sieve Throughput */}
            <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800">
              <div className="text-xs text-slate-400 font-mono uppercase tracking-wider">
                Memory & Branching
              </div>
              <div className="text-3xl font-extrabold font-mono text-emerald-400 mt-2">
                {report.metrics.find(m => m.id === 'prime-sieve')?.opsValue}{' '}
                <span className="text-sm font-normal text-slate-400">MOPS</span>
              </div>
              <p className="text-xs text-slate-500 mt-2">
                Uint8Array sieve up to 3,000,000
              </p>
            </div>

            {/* Total Duration */}
            <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800">
              <div className="text-xs text-slate-400 font-mono uppercase tracking-wider">
                Total Benchmark Time
              </div>
              <div className="text-3xl font-extrabold font-mono text-amber-400 mt-2">
                {report.totalDurationMs}{' '}
                <span className="text-sm font-normal text-slate-400">ms</span>
              </div>
              <p className="text-xs text-slate-500 mt-2">
                Across 5 stress stages
              </p>
            </div>
          </div>

          {/* Detailed Metric Cards Grid */}
          <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <Award className="w-5 h-5 text-cyan-400" />
                  Detailed Computational Breakdown
                </h3>
                <p className="text-xs text-slate-400">
                  Individual pipeline metrics and throughput ratings
                </p>
              </div>

              <div className="flex items-center space-x-2">
                <button
                  onClick={exportReport}
                  className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center space-x-1.5 transition-colors cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Export Scorecard</span>
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {report.metrics.map(metric => (
                <div
                  key={metric.id}
                  className="p-4 rounded-xl bg-slate-950 border border-slate-800/80 space-y-2 hover:border-slate-700 transition-colors"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-xs text-slate-500 font-mono uppercase">
                        {metric.category}
                      </div>
                      <div className="text-sm font-bold text-slate-200">{metric.name}</div>
                    </div>
                    <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-cyan-950 border border-cyan-800 text-cyan-300">
                      {metric.ratingText}
                    </span>
                  </div>

                  <p className="text-xs text-slate-400">{metric.description}</p>

                  <div className="pt-2 flex items-center justify-between text-xs font-mono border-t border-slate-900">
                    <span className="text-slate-400">
                      Throughput:{' '}
                      <strong className="text-cyan-400 font-bold">
                        {metric.opsValue} {metric.unit}
                      </strong>
                    </span>
                    <span className="text-slate-500">{metric.durationMs} ms</span>
                  </div>

                  <div className="text-[11px] text-slate-500 font-mono truncate">
                    {metric.details}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Hardware Baseline Comparison */}
          <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Activity className="w-5 h-5 text-indigo-400" />
              Comparative Hardware Benchmark Leaderboard
            </h3>

            <div className="space-y-3">
              {/* Current Device Score */}
              <div className="p-3 rounded-xl bg-cyan-950/30 border border-cyan-500/40 space-y-1.5">
                <div className="flex justify-between items-center text-xs">
                  <div className="flex items-center space-x-2">
                    <span className="px-1.5 py-0.5 rounded bg-cyan-500 text-slate-950 font-black text-[10px] uppercase">
                      Your Device
                    </span>
                    <span className="font-bold text-cyan-300">
                      {navigator.platform || 'This Client'} ({navigator.hardwareConcurrency || 4} Cores)
                    </span>
                  </div>
                  <span className="font-mono font-bold text-cyan-400 text-sm">
                    {report.totalScore.toLocaleString()} pts
                  </span>
                </div>
                <div className="h-2 w-full bg-slate-950 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-cyan-400 to-indigo-400 rounded-full"
                    style={{ width: `${Math.min(100, (report.totalScore / 4000) * 100)}%` }}
                  />
                </div>
              </div>

              {/* Reference Baselines */}
              {baselines.map(base => (
                <div key={base.name} className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800/80 space-y-1">
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-slate-400">{base.name}</span>
                    <span className="font-mono text-slate-300">{base.score.toLocaleString()} pts</span>
                  </div>
                  <div className="h-1.5 w-full bg-slate-900 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-slate-600 rounded-full"
                      style={{ width: `${(base.score / 4000) * 100}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* If benchmark has not been run yet */}
      {!report && !isRunning && (
        <div className="p-8 rounded-2xl bg-slate-900/60 border border-slate-800 text-center space-y-4 max-w-xl mx-auto">
          <div className="w-12 h-12 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center mx-auto text-cyan-400">
            <Zap className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-white">System Ready for Stress Test</h3>
            <p className="text-xs text-slate-400 mt-1">
              Click the button above to calculate peak single-core and multi-threaded throughput, FPU capability, and real-time linear algebra performance.
            </p>
          </div>
          <button
            onClick={startBenchmark}
            className="px-6 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-sm transition-colors cursor-pointer shadow-lg shadow-cyan-500/20"
          >
            Start Test Now
          </button>
        </div>
      )}
    </div>
  );
};
