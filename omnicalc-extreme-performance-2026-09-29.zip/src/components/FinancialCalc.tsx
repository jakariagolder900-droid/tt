import React, { useState } from 'react';
import { 
  DollarSign, 
  TrendingUp, 
  PieChart, 
  Calendar, 
  Percent, 
  CreditCard,
  Receipt
} from 'lucide-react';
import { sound } from '../utils/audio';

type FinanceTab = 'loan' | 'compound' | 'tip';

export const FinancialCalc: React.FC = () => {
  const [tab, setTab] = useState<FinanceTab>('loan');

  // Loan state
  const [loanAmount, setLoanAmount] = useState<number>(250000);
  const [interestRate, setInterestRate] = useState<number>(6.5);
  const [loanTenureYears, setLoanTenureYears] = useState<number>(30);

  // Compound interest state
  const [initialPrincipal, setInitialPrincipal] = useState<number>(10000);
  const [monthlyContribution, setMonthlyContribution] = useState<number>(500);
  const [investmentRate, setInvestmentRate] = useState<number>(8.0);
  const [investmentYears, setInvestmentYears] = useState<number>(20);

  // Tip state
  const [billAmount, setBillAmount] = useState<number>(85);
  const [tipPercent, setTipPercent] = useState<number>(18);
  const [splitCount, setSplitCount] = useState<number>(2);

  // Loan calculations
  const monthlyRate = interestRate / 100 / 12;
  const totalMonths = loanTenureYears * 12;
  const emi =
    monthlyRate > 0
      ? (loanAmount * monthlyRate * Math.pow(1 + monthlyRate, totalMonths)) /
        (Math.pow(1 + monthlyRate, totalMonths) - 1)
      : loanAmount / totalMonths;

  const totalLoanPayment = emi * totalMonths;
  const totalLoanInterest = totalLoanPayment - loanAmount;

  // Compound interest calculations
  let futureValue = initialPrincipal;
  let totalDeposited = initialPrincipal;
  const monthlyCompRate = investmentRate / 100 / 12;
  const compoundMonths = investmentYears * 12;

  for (let m = 0; m < compoundMonths; m++) {
    futureValue = (futureValue + monthlyContribution) * (1 + monthlyCompRate);
    totalDeposited += monthlyContribution;
  }
  const totalCompInterest = futureValue - totalDeposited;

  // Tip calculations
  const tipAmount = billAmount * (tipPercent / 100);
  const totalBill = billAmount + tipAmount;
  const perPerson = totalBill / Math.max(1, splitCount);

  return (
    <div className="max-w-7xl mx-auto p-3 sm:p-6 space-y-6">
      {/* Sub Tabs */}
      <div className="flex rounded-2xl bg-slate-900 p-1 border border-slate-800 max-w-md">
        {(
          [
            { id: 'loan', label: 'Loan & Mortgage (EMI)', icon: CreditCard },
            { id: 'compound', label: 'Compound Growth', icon: TrendingUp },
            { id: 'tip', label: 'Tip & Split', icon: Receipt },
          ] as { id: FinanceTab; label: string; icon: React.FC<{ className?: string }> }[]
        ).map(t => {
          const Icon = t.icon;
          const isActive = tab === t.id;
          return (
            <button
              key={t.id}
              onClick={() => {
                sound.playClick();
                setTab(t.id);
              }}
              className={`flex-1 flex items-center justify-center space-x-1.5 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                isActive
                  ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{t.label}</span>
            </button>
          );
        })}
      </div>

      {/* Tab 1: Loan & Mortgage */}
      {tab === 'loan' && (
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
          <div className="md:col-span-6 p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
            <h3 className="font-bold text-sm text-slate-200 flex items-center gap-2">
              <CreditCard className="w-4 h-4 text-cyan-400" />
              <span>Loan Parameters</span>
            </h3>

            <div className="space-y-3">
              <div>
                <label className="text-xs text-slate-400">Principal Loan Amount ($)</label>
                <input
                  type="number"
                  value={loanAmount}
                  onChange={e => setLoanAmount(Number(e.target.value))}
                  className="w-full bg-slate-950 px-3.5 py-2.5 rounded-xl border border-slate-800 font-mono text-white text-lg focus:border-cyan-500 outline-none"
                />
              </div>

              <div>
                <label className="text-xs text-slate-400">Annual Interest Rate (%)</label>
                <input
                  type="number"
                  step="0.1"
                  value={interestRate}
                  onChange={e => setInterestRate(Number(e.target.value))}
                  className="w-full bg-slate-950 px-3.5 py-2.5 rounded-xl border border-slate-800 font-mono text-white text-lg focus:border-cyan-500 outline-none"
                />
              </div>

              <div>
                <label className="text-xs text-slate-400">Loan Term (Years)</label>
                <input
                  type="number"
                  value={loanTenureYears}
                  onChange={e => setLoanTenureYears(Number(e.target.value))}
                  className="w-full bg-slate-950 px-3.5 py-2.5 rounded-xl border border-slate-800 font-mono text-white text-lg focus:border-cyan-500 outline-none"
                />
              </div>
            </div>
          </div>

          <div className="md:col-span-6 p-6 rounded-2xl bg-slate-900 border border-cyan-500/30 space-y-4 flex flex-col justify-between shadow-2xl">
            <div>
              <div className="text-xs text-slate-400 uppercase tracking-wider font-mono">
                Monthly Payment (EMI)
              </div>
              <div className="text-4xl sm:text-5xl font-extrabold font-mono text-cyan-400 mt-2">
                ${Math.round(emi).toLocaleString()}
                <span className="text-sm font-normal text-slate-400">/mo</span>
              </div>
            </div>

            <div className="space-y-3 pt-4 border-t border-slate-800 text-sm">
              <div className="flex justify-between items-center text-slate-300">
                <span className="text-slate-400">Total Principal:</span>
                <span className="font-mono font-bold">${loanAmount.toLocaleString()}</span>
              </div>
              <div className="flex justify-between items-center text-slate-300">
                <span className="text-slate-400">Total Interest Payable:</span>
                <span className="font-mono font-bold text-amber-400">
                  ${Math.round(totalLoanInterest).toLocaleString()}
                </span>
              </div>
              <div className="flex justify-between items-center text-slate-300 pt-2 border-t border-slate-800 font-bold">
                <span>Total Overall Payment:</span>
                <span className="font-mono text-cyan-300">
                  ${Math.round(totalLoanPayment).toLocaleString()}
                </span>
              </div>
            </div>

            {/* Visual ratio bar */}
            <div className="space-y-1.5 pt-2">
              <div className="flex justify-between text-[11px] text-slate-400 font-mono">
                <span>Principal: {Math.round((loanAmount / totalLoanPayment) * 100)}%</span>
                <span>Interest: {Math.round((totalLoanInterest / totalLoanPayment) * 100)}%</span>
              </div>
              <div className="h-2 w-full bg-slate-950 rounded-full overflow-hidden flex">
                <div
                  className="h-full bg-cyan-500"
                  style={{ width: `${(loanAmount / totalLoanPayment) * 100}%` }}
                />
                <div
                  className="h-full bg-amber-500"
                  style={{ width: `${(totalLoanInterest / totalLoanPayment) * 100}%` }}
                />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Compound Interest */}
      {tab === 'compound' && (
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
          <div className="md:col-span-6 p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
            <h3 className="font-bold text-sm text-slate-200 flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-emerald-400" />
              <span>Investment Parameters</span>
            </h3>

            <div className="space-y-3">
              <div>
                <label className="text-xs text-slate-400">Starting Principal ($)</label>
                <input
                  type="number"
                  value={initialPrincipal}
                  onChange={e => setInitialPrincipal(Number(e.target.value))}
                  className="w-full bg-slate-950 px-3.5 py-2.5 rounded-xl border border-slate-800 font-mono text-white text-lg focus:border-cyan-500 outline-none"
                />
              </div>

              <div>
                <label className="text-xs text-slate-400">Monthly Contribution ($)</label>
                <input
                  type="number"
                  value={monthlyContribution}
                  onChange={e => setMonthlyContribution(Number(e.target.value))}
                  className="w-full bg-slate-950 px-3.5 py-2.5 rounded-xl border border-slate-800 font-mono text-white text-lg focus:border-cyan-500 outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-slate-400">Annual Return (%)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={investmentRate}
                    onChange={e => setInvestmentRate(Number(e.target.value))}
                    className="w-full bg-slate-950 px-3.5 py-2.5 rounded-xl border border-slate-800 font-mono text-white text-lg focus:border-cyan-500 outline-none"
                  />
                </div>
                <div>
                  <label className="text-xs text-slate-400">Years to Grow</label>
                  <input
                    type="number"
                    value={investmentYears}
                    onChange={e => setInvestmentYears(Number(e.target.value))}
                    className="w-full bg-slate-950 px-3.5 py-2.5 rounded-xl border border-slate-800 font-mono text-white text-lg focus:border-cyan-500 outline-none"
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="md:col-span-6 p-6 rounded-2xl bg-slate-900 border border-emerald-500/30 space-y-4 flex flex-col justify-between shadow-2xl">
            <div>
              <div className="text-xs text-slate-400 uppercase tracking-wider font-mono">
                Estimated Future Value
              </div>
              <div className="text-4xl sm:text-5xl font-extrabold font-mono text-emerald-400 mt-2">
                ${Math.round(futureValue).toLocaleString()}
              </div>
            </div>

            <div className="space-y-3 pt-4 border-t border-slate-800 text-sm">
              <div className="flex justify-between items-center text-slate-300">
                <span className="text-slate-400">Total Deposits:</span>
                <span className="font-mono font-bold">${Math.round(totalDeposited).toLocaleString()}</span>
              </div>
              <div className="flex justify-between items-center text-slate-300">
                <span className="text-slate-400">Total Interest Earned:</span>
                <span className="font-mono font-bold text-emerald-400">
                  +${Math.round(totalCompInterest).toLocaleString()}
                </span>
              </div>
            </div>

            {/* Growth multiplier badge */}
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800/80 flex items-center justify-between text-xs font-mono">
              <span className="text-slate-400">Total Return Multiplier:</span>
              <span className="text-emerald-400 font-bold text-sm">
                {(futureValue / Math.max(1, totalDeposited)).toFixed(2)}x Growth
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: Tip & Split */}
      {tab === 'tip' && (
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
          <div className="md:col-span-6 p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
            <h3 className="font-bold text-sm text-slate-200 flex items-center gap-2">
              <Receipt className="w-4 h-4 text-cyan-400" />
              <span>Bill Details</span>
            </h3>

            <div className="space-y-3">
              <div>
                <label className="text-xs text-slate-400">Bill Subtotal ($)</label>
                <input
                  type="number"
                  value={billAmount}
                  onChange={e => setBillAmount(Number(e.target.value))}
                  className="w-full bg-slate-950 px-3.5 py-2.5 rounded-xl border border-slate-800 font-mono text-white text-lg focus:border-cyan-500 outline-none"
                />
              </div>

              <div>
                <label className="text-xs text-slate-400">Tip Percentage (%)</label>
                <div className="grid grid-cols-4 gap-2 mt-1">
                  {[10, 15, 18, 20].map(p => (
                    <button
                      key={p}
                      onClick={() => setTipPercent(p)}
                      className={`py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                        tipPercent === p
                          ? 'bg-cyan-500 text-slate-950'
                          : 'bg-slate-950 border border-slate-800 text-slate-400 hover:text-white'
                      }`}
                    >
                      {p}%
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-xs text-slate-400">Split Between (People)</label>
                <input
                  type="number"
                  min={1}
                  value={splitCount}
                  onChange={e => setSplitCount(Math.max(1, Number(e.target.value)))}
                  className="w-full bg-slate-950 px-3.5 py-2.5 rounded-xl border border-slate-800 font-mono text-white text-lg focus:border-cyan-500 outline-none"
                />
              </div>
            </div>
          </div>

          <div className="md:col-span-6 p-6 rounded-2xl bg-slate-900 border border-cyan-500/30 space-y-4 flex flex-col justify-between shadow-2xl">
            <div>
              <div className="text-xs text-slate-400 uppercase tracking-wider font-mono">
                Amount Per Person
              </div>
              <div className="text-4xl sm:text-5xl font-extrabold font-mono text-cyan-400 mt-2">
                ${perPerson.toFixed(2)}
              </div>
            </div>

            <div className="space-y-3 pt-4 border-t border-slate-800 text-sm">
              <div className="flex justify-between items-center text-slate-300">
                <span className="text-slate-400">Tip Amount ({tipPercent}%):</span>
                <span className="font-mono font-bold text-amber-400">${tipAmount.toFixed(2)}</span>
              </div>
              <div className="flex justify-between items-center text-slate-300">
                <span className="text-slate-400">Total Bill + Tip:</span>
                <span className="font-mono font-bold text-white">${totalBill.toFixed(2)}</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
