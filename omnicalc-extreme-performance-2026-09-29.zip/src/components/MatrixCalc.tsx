import React, { useState } from 'react';
import { 
  Grid3X3, 
  RotateCcw, 
  Copy, 
  Check, 
  Sparkles, 
  Divide, 
  ArrowRight,
  Maximize2
} from 'lucide-react';
import { 
  Matrix, 
  createMatrix, 
  matrixAdd, 
  matrixSub, 
  matrixMultiply, 
  matrixScale, 
  matrixTranspose, 
  matrixDeterminant, 
  matrixInverse, 
  matrixTrace 
} from '../utils/matrixEngine';
import { sound } from '../utils/audio';

export const MatrixCalc: React.FC = () => {
  const [size, setSize] = useState<number>(3);
  const [matrixA, setMatrixA] = useState<Matrix>(() => [
    [1, 2, 3],
    [0, 1, 4],
    [5, 6, 0],
  ]);
  const [matrixB, setMatrixB] = useState<Matrix>(() => [
    [2, 0, -1],
    [1, 3, 2],
    [0, -2, 1],
  ]);

  const [resultMatrix, setResultMatrix] = useState<Matrix | null>(null);
  const [scalarResult, setScalarResult] = useState<number | null>(null);
  const [statusMessage, setStatusMessage] = useState<string>('');
  const [scalarK, setScalarK] = useState<number>(2);
  const [copied, setCopied] = useState<boolean>(false);

  const handleResize = (newSize: number) => {
    sound.playClick();
    setSize(newSize);

    const resize = (old: Matrix) => {
      const next = createMatrix(newSize, newSize, 0);
      for (let i = 0; i < Math.min(newSize, old.length); i++) {
        for (let j = 0; j < Math.min(newSize, old[0].length); j++) {
          next[i][j] = old[i][j];
        }
      }
      return next;
    };

    setMatrixA(resize(matrixA));
    setMatrixB(resize(matrixB));
    setResultMatrix(null);
    setScalarResult(null);
  };

  const updateCell = (matrix: 'A' | 'B', row: number, col: number, val: number) => {
    if (matrix === 'A') {
      const next = matrixA.map((r, i) => r.map((c, j) => (i === row && j === col ? val : c)));
      setMatrixA(next);
    } else {
      const next = matrixB.map((r, i) => r.map((c, j) => (i === row && j === col ? val : c)));
      setMatrixB(next);
    }
  };

  const setIdentity = (target: 'A' | 'B') => {
    sound.playClick();
    const ident = createMatrix(size, size, 0);
    for (let i = 0; i < size; i++) ident[i][i] = 1;
    if (target === 'A') setMatrixA(ident);
    else setMatrixB(ident);
  };

  const clearMatrix = (target: 'A' | 'B') => {
    sound.playClear();
    const zero = createMatrix(size, size, 0);
    if (target === 'A') setMatrixA(zero);
    else setMatrixB(zero);
  };

  const executeOp = (op: string) => {
    sound.playOperator();
    setStatusMessage('');
    setScalarResult(null);

    try {
      switch (op) {
        case 'ADD':
          setResultMatrix(matrixAdd(matrixA, matrixB));
          setStatusMessage('Matrix Addition: A + B');
          break;
        case 'SUB':
          setResultMatrix(matrixSub(matrixA, matrixB));
          setStatusMessage('Matrix Subtraction: A - B');
          break;
        case 'MUL':
          setResultMatrix(matrixMultiply(matrixA, matrixB));
          setStatusMessage('Matrix Multiplication: A × B');
          break;
        case 'TRANSPOSE_A':
          setResultMatrix(matrixTranspose(matrixA));
          setStatusMessage('Transpose of Matrix A (Aᵀ)');
          break;
        case 'TRANSPOSE_B':
          setResultMatrix(matrixTranspose(matrixB));
          setStatusMessage('Transpose of Matrix B (Bᵀ)');
          break;
        case 'DET_A': {
          const d = matrixDeterminant(matrixA);
          setScalarResult(Number(d.toFixed(6)));
          setStatusMessage('Determinant: det(A)');
          setResultMatrix(null);
          break;
        }
        case 'DET_B': {
          const d = matrixDeterminant(matrixB);
          setScalarResult(Number(d.toFixed(6)));
          setStatusMessage('Determinant: det(B)');
          setResultMatrix(null);
          break;
        }
        case 'INV_A':
          setResultMatrix(matrixInverse(matrixA));
          setStatusMessage('Matrix Inverse: A⁻¹');
          break;
        case 'INV_B':
          setResultMatrix(matrixInverse(matrixB));
          setStatusMessage('Matrix Inverse: B⁻¹');
          break;
        case 'SCALE_A':
          setResultMatrix(matrixScale(matrixA, scalarK));
          setStatusMessage(`Scalar Multiplication: ${scalarK} × A`);
          break;
        case 'TRACE_A': {
          const tr = matrixTrace(matrixA);
          setScalarResult(tr);
          setStatusMessage('Matrix Trace: tr(A)');
          setResultMatrix(null);
          break;
        }
      }
      sound.playEqual();
    } catch (err: unknown) {
      sound.playError();
      const message = err instanceof Error ? err.message : 'Matrix operation error';
      setStatusMessage(`Error: ${message}`);
      setResultMatrix(null);
    }
  };

  const copyResult = () => {
    if (!resultMatrix) return;
    const str = resultMatrix.map(r => r.join('\t')).join('\n');
    navigator.clipboard.writeText(str);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  return (
    <div className="max-w-7xl mx-auto p-3 sm:p-6 space-y-6">
      {/* Header controls: dimension picker */}
      <div className="flex items-center justify-between p-3 rounded-2xl bg-slate-900 border border-slate-800 text-xs">
        <div className="flex items-center space-x-2">
          <span className="text-slate-400 font-medium">Dimension:</span>
          {[2, 3, 4].map(s => (
            <button
              key={s}
              onClick={() => handleResize(s)}
              className={`px-3 py-1 rounded-lg font-mono font-bold transition-all cursor-pointer ${
                size === s
                  ? 'bg-cyan-500 text-slate-950 shadow-sm shadow-cyan-500/30'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
              }`}
            >
              {s} × {s}
            </button>
          ))}
        </div>

        <div className="flex items-center space-x-2">
          <span className="text-slate-500 font-mono text-xs">Float64 Double Precision</span>
        </div>
      </div>

      {/* Matrix Inputs Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Matrix A */}
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <h3 className="font-bold text-sm text-cyan-400 font-mono">Matrix A</h3>
            <div className="flex items-center space-x-1.5 text-xs">
              <button
                onClick={() => setIdentity('A')}
                className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 hover:text-cyan-400 font-mono cursor-pointer"
                title="Identity Matrix"
              >
                I
              </button>
              <button
                onClick={() => clearMatrix('A')}
                className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 hover:text-rose-400 font-mono cursor-pointer"
                title="Zero Matrix"
              >
                0
              </button>
            </div>
          </div>

          <div
            className="grid gap-2"
            style={{ gridTemplateColumns: `repeat(${size}, minmax(0, 1fr))` }}
          >
            {matrixA.map((row, r) =>
              row.map((val, c) => (
                <input
                  key={`a-${r}-${c}`}
                  type="number"
                  value={val}
                  onChange={e => updateCell('A', r, c, Number(e.target.value))}
                  className="w-full bg-slate-950 p-2 sm:p-3 rounded-xl border border-slate-800 text-center font-mono text-white text-base focus:border-cyan-500 outline-none"
                />
              ))
            )}
          </div>
        </div>

        {/* Matrix B */}
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <h3 className="font-bold text-sm text-indigo-400 font-mono">Matrix B</h3>
            <div className="flex items-center space-x-1.5 text-xs">
              <button
                onClick={() => setIdentity('B')}
                className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 hover:text-indigo-400 font-mono cursor-pointer"
                title="Identity Matrix"
              >
                I
              </button>
              <button
                onClick={() => clearMatrix('B')}
                className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 hover:text-rose-400 font-mono cursor-pointer"
                title="Zero Matrix"
              >
                0
              </button>
            </div>
          </div>

          <div
            className="grid gap-2"
            style={{ gridTemplateColumns: `repeat(${size}, minmax(0, 1fr))` }}
          >
            {matrixB.map((row, r) =>
              row.map((val, c) => (
                <input
                  key={`b-${r}-${c}`}
                  type="number"
                  value={val}
                  onChange={e => updateCell('B', r, c, Number(e.target.value))}
                  className="w-full bg-slate-950 p-2 sm:p-3 rounded-xl border border-slate-800 text-center font-mono text-white text-base focus:border-indigo-500 outline-none"
                />
              ))
            )}
          </div>
        </div>
      </div>

      {/* Operations Bar */}
      <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
        <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
          Matrix Operations
        </h4>
        <div className="flex flex-wrap gap-2 text-xs font-mono font-bold">
          <button onClick={() => executeOp('ADD')} className="calc-btn text-cyan-300 bg-slate-950">
            A + B
          </button>
          <button onClick={() => executeOp('SUB')} className="calc-btn text-cyan-300 bg-slate-950">
            A − B
          </button>
          <button onClick={() => executeOp('MUL')} className="calc-btn text-cyan-300 bg-slate-950">
            A × B
          </button>
          <button onClick={() => executeOp('DET_A')} className="calc-btn text-indigo-300 bg-slate-950">
            det(A)
          </button>
          <button onClick={() => executeOp('DET_B')} className="calc-btn text-indigo-300 bg-slate-950">
            det(B)
          </button>
          <button onClick={() => executeOp('INV_A')} className="calc-btn text-indigo-300 bg-slate-950">
            A⁻¹
          </button>
          <button onClick={() => executeOp('INV_B')} className="calc-btn text-indigo-300 bg-slate-950">
            B⁻¹
          </button>
          <button onClick={() => executeOp('TRANSPOSE_A')} className="calc-btn text-amber-300 bg-slate-950">
            Aᵀ
          </button>
          <button onClick={() => executeOp('TRANSPOSE_B')} className="calc-btn text-amber-300 bg-slate-950">
            Bᵀ
          </button>
          <button onClick={() => executeOp('TRACE_A')} className="calc-btn text-emerald-300 bg-slate-950">
            tr(A)
          </button>
          <button onClick={() => executeOp('SCALE_A')} className="calc-btn text-cyan-400 bg-slate-950">
            k × A
          </button>
          <div className="flex items-center space-x-1 pl-2">
            <span className="text-slate-400 text-xs">k =</span>
            <input
              type="number"
              value={scalarK}
              onChange={e => setScalarK(Number(e.target.value))}
              className="w-14 bg-slate-950 border border-slate-800 rounded px-2 py-1 text-center text-cyan-400 font-mono text-xs"
            />
          </div>
        </div>
      </div>

      {/* Result Display */}
      {(resultMatrix || scalarResult !== null || statusMessage) && (
        <div className="p-5 rounded-2xl bg-slate-900 border border-cyan-500/40 shadow-2xl space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <div className="flex items-center space-x-2">
              <Sparkles className="w-4 h-4 text-cyan-400" />
              <span className="font-bold text-sm text-cyan-300 font-mono">{statusMessage}</span>
            </div>
            {resultMatrix && (
              <button
                onClick={copyResult}
                className="p-1.5 rounded hover:bg-slate-800 text-slate-400 hover:text-cyan-400 transition-colors"
                title="Copy Result Matrix"
              >
                {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              </button>
            )}
          </div>

          {resultMatrix && (
            <div
              className="grid gap-2 max-w-md mx-auto"
              style={{ gridTemplateColumns: `repeat(${resultMatrix[0].length}, minmax(0, 1fr))` }}
            >
              {resultMatrix.map((row, r) =>
                row.map((val, c) => (
                  <div
                    key={`res-${r}-${c}`}
                    className="p-3 rounded-xl bg-slate-950 border border-slate-800/80 text-center font-mono font-bold text-white text-base overflow-hidden truncate"
                  >
                    {Number(val.toFixed(4))}
                  </div>
                ))
              )}
            </div>
          )}

          {scalarResult !== null && (
            <div className="text-center py-4">
              <span className="text-4xl font-extrabold font-mono text-cyan-400">
                {scalarResult}
              </span>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
