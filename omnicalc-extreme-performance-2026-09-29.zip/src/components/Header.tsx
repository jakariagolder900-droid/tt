import React from 'react';
import { 
  Calculator, 
  Activity, 
  Zap, 
  Binary, 
  Ruler, 
  DollarSign, 
  Grid3X3, 
  Sparkles, 
  Volume2, 
  VolumeX, 
  Keyboard, 
  Cpu,
  Download
} from 'lucide-react';
import { AppMode } from '../types';
import { sound } from '../utils/audio';

interface HeaderProps {
  currentMode: AppMode;
  onSelectMode: (mode: AppMode) => void;
  onOpenHelp: () => void;
  onOpenDownload: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentMode,
  onSelectMode,
  onOpenHelp,
  onOpenDownload,
}) => {
  const [soundEnabled, setSoundEnabled] = React.useState(sound.enabled);

  const toggleAudio = () => {
    const next = sound.toggleSound();
    setSoundEnabled(next);
  };

  const navItems: { id: AppMode; label: string; icon: React.FC<{ className?: string }>; badge?: string }[] = [
    { id: 'scientific', label: 'Scientific', icon: Calculator },
    { id: 'graphing', label: 'Graphing 2D', icon: Activity },
    { id: 'benchmark', label: 'Extreme Benchmark', icon: Zap, badge: 'STRESS' },
    { id: 'programmer', label: 'Programmer 64-Bit', icon: Binary },
    { id: 'units', label: 'Omni Converter', icon: Ruler },
    { id: 'matrix', label: 'Matrix Lab', icon: Grid3X3 },
    { id: 'finance', label: 'Financial', icon: DollarSign },
    { id: 'fractal', label: 'Chaos Explorer', icon: Sparkles },
  ];

  return (
    <header className="border-b border-slate-800 bg-slate-900/90 backdrop-blur-md sticky top-0 z-40 px-3 sm:px-6 py-2.5">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center justify-between gap-3">
        {/* Brand identity */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="relative flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-600 via-indigo-600 to-violet-500 shadow-lg shadow-cyan-500/20 text-white font-black tracking-wider">
              <span className="text-xl font-mono">Ω</span>
              <span className="absolute -top-1 -right-1 flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-cyan-500"></span>
              </span>
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h1 className="text-lg sm:text-xl font-bold tracking-tight text-white flex items-center gap-1.5">
                  OmniCalc
                  <span className="text-xs uppercase font-extrabold px-1.5 py-0.5 rounded bg-gradient-to-r from-cyan-500 to-indigo-500 text-slate-950 tracking-wider">
                    Extreme
                  </span>
                </h1>
              </div>
              <p className="text-xs text-slate-400 hidden sm:block">
                Ultra-Precision Compute Engine & Hardware Benchmark
              </p>
            </div>
          </div>

          {/* Mobile Right Controls */}
          <div className="flex items-center space-x-1 md:hidden">
            <button
              onClick={() => {
                sound.playClick();
                onOpenDownload();
              }}
              className="p-2 rounded-lg border border-cyan-500/40 bg-cyan-500/10 text-cyan-400 hover:bg-cyan-500/20"
              title="Download & Install"
            >
              <Download className="w-4 h-4" />
            </button>
            <button
              onClick={toggleAudio}
              className={`p-2 rounded-lg border transition-all ${
                soundEnabled
                  ? 'border-cyan-500/40 bg-cyan-500/10 text-cyan-400'
                  : 'border-slate-800 bg-slate-800/60 text-slate-500'
              }`}
              title={soundEnabled ? 'Audio feedback: ON' : 'Audio feedback: MUTED'}
            >
              {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            </button>
            <button
              onClick={onOpenHelp}
              className="p-2 rounded-lg border border-slate-800 bg-slate-800/60 text-slate-300 hover:text-white"
              title="Keyboard shortcuts"
            >
              <Keyboard className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Mode selector pills */}
        <nav className="flex items-center space-x-1 overflow-x-auto pb-1 md:pb-0 scrollbar-none text-xs sm:text-sm">
          {navItems.map(item => {
            const Icon = item.icon;
            const isActive = currentMode === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  sound.playClick();
                  onSelectMode(item.id);
                }}
                className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg whitespace-nowrap font-medium transition-all cursor-pointer relative ${
                  isActive
                    ? 'bg-cyan-500/15 text-cyan-300 border border-cyan-500/40 shadow-sm shadow-cyan-500/10'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60 border border-transparent'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-cyan-400' : 'text-slate-400'}`} />
                <span>{item.label}</span>
                {item.badge && (
                  <span className="text-[9px] uppercase px-1 py-0.2 rounded font-black bg-amber-500/20 text-amber-300 border border-amber-500/30">
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Desktop Quick Tools */}
        <div className="hidden md:flex items-center space-x-2">
          <button
            onClick={() => {
              sound.playClick();
              onOpenDownload();
            }}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-400 border border-cyan-500/40 text-xs font-semibold transition-all cursor-pointer shadow-sm shadow-cyan-500/10"
            title="Download Project ZIP or Install PWA"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download</span>
          </button>

          <div className="flex items-center space-x-1 px-2.5 py-1 rounded-lg bg-slate-950/80 border border-slate-800/80 text-[11px] text-slate-400 font-mono">
            <Cpu className="w-3.5 h-3.5 text-cyan-400" />
            <span>{navigator.hardwareConcurrency || 4} Cores</span>
          </div>

          <button
            onClick={toggleAudio}
            className={`p-2 rounded-lg border transition-all cursor-pointer ${
              soundEnabled
                ? 'border-cyan-500/40 bg-cyan-500/10 text-cyan-400 hover:bg-cyan-500/20'
                : 'border-slate-800 bg-slate-900 text-slate-500 hover:text-slate-300'
            }`}
            title={soundEnabled ? 'Audio feedback: ON' : 'Audio feedback: MUTED'}
          >
            {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>

          <button
            onClick={onOpenHelp}
            className="p-2 rounded-lg border border-slate-800 bg-slate-900 text-slate-400 hover:text-white hover:border-slate-700 transition-all cursor-pointer"
            title="Keyboard shortcuts & Quick Guide"
          >
            <Keyboard className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
};
