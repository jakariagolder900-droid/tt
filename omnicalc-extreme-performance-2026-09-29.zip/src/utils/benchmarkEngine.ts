export interface BenchmarkMetric {
  id: string;
  name: string;
  category: string;
  description: string;
  durationMs: number;
  score: number;
  ratingText: string;
  unit: string;
  opsValue: number;
  details: string;
}

export interface BenchmarkReport {
  totalScore: number;
  hardwareTier: string;
  totalDurationMs: number;
  timestamp: number;
  metrics: BenchmarkMetric[];
  deviceInfo: {
    logicalCores: number;
    platform: string;
    userAgent: string;
    memoryEstimate?: string;
  };
}

// 1. Monte Carlo Pi Benchmark
export function runMonteCarloPi(iterations = 4_000_000): { durationMs: number; estimatedPi: number; mops: number } {
  const start = performance.now();
  let inside = 0;

  // Linear congruential generator for deterministic speed
  let seed = 123456789;
  const a = 1664525;
  const c = 1013904223;
  const m = 4294967296;

  for (let i = 0; i < iterations; i++) {
    seed = (a * seed + c) % m;
    const x = seed / m;
    seed = (a * seed + c) % m;
    const y = seed / m;
    if (x * x + y * y <= 1.0) {
      inside++;
    }
  }

  const durationMs = Math.max(performance.now() - start, 1);
  const estimatedPi = (4 * inside) / iterations;
  const mops = (iterations / (durationMs / 1000)) / 1_000_000;

  return { durationMs, estimatedPi, mops };
}

// 2. Matrix Multiplication GEMM (GFLOPS)
export function runMatrixMultiplyBenchmark(size = 180, repeats = 4): { durationMs: number; gflops: number } {
  const A = new Float64Array(size * size);
  const B = new Float64Array(size * size);
  const C = new Float64Array(size * size);

  for (let i = 0; i < size * size; i++) {
    A[i] = Math.sin(i);
    B[i] = Math.cos(i);
  }

  const start = performance.now();

  for (let rep = 0; rep < repeats; rep++) {
    for (let i = 0; i < size; i++) {
      const iOffset = i * size;
      for (let k = 0; k < size; k++) {
        const aik = A[iOffset + k];
        const kOffset = k * size;
        for (let j = 0; j < size; j++) {
          C[iOffset + j] += aik * B[kOffset + j];
        }
      }
    }
  }

  const durationMs = Math.max(performance.now() - start, 1);
  // Total FLOPs = repeats * 2 * size^3
  const totalFlops = repeats * 2 * Math.pow(size, 3);
  const gflops = (totalFlops / (durationMs / 1000)) / 1_000_000_000;

  return { durationMs, gflops };
}

// 3. Sieve of Eratosthenes (Prime generation)
export function runPrimeSieveBenchmark(limit = 3_000_000): { durationMs: number; primeCount: number; mops: number } {
  const start = performance.now();
  const sieve = new Uint8Array(limit + 1);
  let count = 0;

  sieve[0] = 1;
  sieve[1] = 1;
  const sqrtLimit = Math.floor(Math.sqrt(limit));

  for (let i = 2; i <= sqrtLimit; i++) {
    if (sieve[i] === 0) {
      for (let j = i * i; j <= limit; j += i) {
        sieve[j] = 1;
      }
    }
  }

  for (let i = 2; i <= limit; i++) {
    if (sieve[i] === 0) count++;
  }

  const durationMs = Math.max(performance.now() - start, 1);
  const mops = (limit / (durationMs / 1000)) / 1_000_000;

  return { durationMs, primeCount: count, mops };
}

// 4. Mandelbrot Iteration Stress
export function runMandelbrotBenchmark(width = 400, height = 400, maxIter = 500): { durationMs: number; totalIters: number; megaItersPerSec: number } {
  const start = performance.now();
  let totalIterations = 0;

  const minR = -2.0;
  const maxR = 1.0;
  const minI = -1.2;
  const maxI = 1.2;

  const stepR = (maxR - minR) / width;
  const stepI = (maxI - minI) / height;

  for (let y = 0; y < height; y++) {
    const ci = minI + y * stepI;
    for (let x = 0; x < width; x++) {
      const cr = minR + x * stepR;
      let zr = 0.0;
      let zi = 0.0;
      let iter = 0;

      while (zr * zr + zi * zi <= 4.0 && iter < maxIter) {
        const nextZr = zr * zr - zi * zi + cr;
        zi = 2.0 * zr * zi + ci;
        zr = nextZr;
        iter++;
      }
      totalIterations += iter;
    }
  }

  const durationMs = Math.max(performance.now() - start, 1);
  const megaItersPerSec = (totalIterations / (durationMs / 1000)) / 1_000_000;

  return { durationMs, totalIters: totalIterations, megaItersPerSec };
}

// 5. Transcendental & Trigonometric Stress
export function runTranscendentalBenchmark(iterations = 2_000_000): { durationMs: number; mops: number } {
  const start = performance.now();
  let accum = 0.5;

  for (let i = 1; i <= iterations; i++) {
    accum = Math.sin(accum * 0.1) + Math.cos(accum * 0.05) + Math.sqrt(Math.abs(accum) + 1.0) + Math.log(Math.abs(accum) + 1.1);
  }

  const durationMs = Math.max(performance.now() - start, 1);
  // 4 transcendental ops per loop
  const totalOps = iterations * 4;
  const mops = (totalOps / (durationMs / 1000)) / 1_000_000;

  return { durationMs, mops };
}

export async function runFullBenchmarkSuite(
  onProgress?: (currentTest: string, percent: number) => void
): Promise<BenchmarkReport> {
  const metrics: BenchmarkMetric[] = [];
  const overallStart = performance.now();

  // Test 1: Monte Carlo
  onProgress?.('Monte Carlo Pi Simulation (Stochastic FP)', 15);
  await new Promise(r => setTimeout(r, 40));
  const mc = runMonteCarloPi();
  const mcScore = Math.round(mc.mops * 85);
  metrics.push({
    id: 'monte-carlo',
    name: 'Monte Carlo Pi FP Engine',
    category: 'Stochastic Compute',
    description: '4,000,000 point random vector simulation to compute circular geometric convergence.',
    durationMs: Math.round(mc.durationMs),
    score: mcScore,
    ratingText: mc.mops > 30 ? 'Ultra Fast' : mc.mops > 15 ? 'Excellent' : 'Normal',
    unit: 'MOPS',
    opsValue: Number(mc.mops.toFixed(2)),
    details: `Estimated π: ${mc.estimatedPi.toFixed(6)} | Error: ${Math.abs(mc.estimatedPi - Math.PI).toExponential(3)}`,
  });

  // Test 2: Matrix Multiply
  onProgress?.('Float64 GEMM Matrix Compute (Peak FLOPS)', 35);
  await new Promise(r => setTimeout(r, 40));
  const mm = runMatrixMultiplyBenchmark();
  const mmScore = Math.round(mm.gflops * 1200);
  metrics.push({
    id: 'matrix-gemm',
    name: 'Float64 GEMM Dense Matrix Operations',
    category: 'Linear Algebra Compute',
    description: 'Triple nested cache-stressed matrix multiplication computing double-precision operations.',
    durationMs: Math.round(mm.durationMs),
    score: mmScore,
    ratingText: mm.gflops > 1.8 ? 'Hyper-Threading Elite' : mm.gflops > 0.8 ? 'Great' : 'Standard',
    unit: 'GFLOPS',
    opsValue: Number(mm.gflops.toFixed(3)),
    details: `Execution time: ${mm.durationMs.toFixed(1)}ms across 4 repeats of 180×180 matrices`,
  });

  // Test 3: Prime Sieve
  onProgress?.('Sieve of Eratosthenes (Bit & Memory Bandwidth)', 55);
  await new Promise(r => setTimeout(r, 40));
  const sieve = runPrimeSieveBenchmark();
  const sieveScore = Math.round(sieve.mops * 60);
  metrics.push({
    id: 'prime-sieve',
    name: 'Sieve of Eratosthenes Prime Engine',
    category: 'Memory & Branching',
    description: 'Uint8Array direct memory mutation and branch prediction stress up to 3,000,000.',
    durationMs: Math.round(sieve.durationMs),
    score: sieveScore,
    ratingText: sieve.mops > 70 ? 'Extreme Throughput' : sieve.mops > 35 ? 'Fast' : 'Good',
    unit: 'MOPS',
    opsValue: Number(sieve.mops.toFixed(1)),
    details: `Identified ${sieve.primeCount.toLocaleString()} primes under 3,000,000`,
  });

  // Test 4: Mandelbrot
  onProgress?.('Mandelbrot Chaos Iterator (Complex Arithmetic)', 75);
  await new Promise(r => setTimeout(r, 40));
  const mandel = runMandelbrotBenchmark();
  const mandelScore = Math.round(mandel.megaItersPerSec * 80);
  metrics.push({
    id: 'mandelbrot',
    name: 'Mandelbrot Complex Iteration Engine',
    category: 'Fractal Calculus',
    description: 'Complex plane escape-time computation over 160,000 pixels with dynamic convergence testing.',
    durationMs: Math.round(mandel.durationMs),
    score: mandelScore,
    ratingText: mandel.megaItersPerSec > 40 ? 'Extreme Core' : mandel.megaItersPerSec > 20 ? 'Optimal' : 'Standard',
    unit: 'M-Iter/s',
    opsValue: Number(mandel.megaItersPerSec.toFixed(2)),
    details: `Executed ${mandel.totalIters.toLocaleString()} complex number iterations`,
  });

  // Test 5: Transcendentals
  onProgress?.('Transcendental Function Stress (sin/cos/log/sqrt)', 95);
  await new Promise(r => setTimeout(r, 40));
  const trans = runTranscendentalBenchmark();
  const transScore = Math.round(trans.mops * 70);
  metrics.push({
    id: 'transcendental',
    name: 'Nonlinear Transcendental Math Pipeline',
    category: 'FPU Trigonometry',
    description: 'High-density sine, cosine, natural logarithm, and radical calculations.',
    durationMs: Math.round(trans.durationMs),
    score: transScore,
    ratingText: trans.mops > 50 ? 'Elite Pipeline' : trans.mops > 25 ? 'High Speed' : 'Normal',
    unit: 'MOPS',
    opsValue: Number(trans.mops.toFixed(1)),
    details: `8,000,000 transcendental math operations computed`,
  });

  onProgress?.('Generating Performance Certificate', 100);

  const totalDurationMs = Math.round(performance.now() - overallStart);
  const totalScore = Math.round(
    metrics.reduce((acc, m) => acc + m.score, 0) / metrics.length
  );

  let hardwareTier = 'Standard Device';
  if (totalScore >= 3500) hardwareTier = 'Extreme Workstation (God Tier)';
  else if (totalScore >= 2500) hardwareTier = 'Flagship Performance (Tier S)';
  else if (totalScore >= 1600) hardwareTier = 'High-End Compute (Tier A)';
  else if (totalScore >= 1000) hardwareTier = 'Mainstream Balanced (Tier B)';
  else hardwareTier = 'Entry Device (Tier C)';

  const deviceMemory = (navigator as unknown as { deviceMemory?: number }).deviceMemory;
  const memoryEstimate = deviceMemory ? `${deviceMemory} GB RAM` : 'System managed';

  return {
    totalScore,
    hardwareTier,
    totalDurationMs,
    timestamp: Date.now(),
    metrics,
    deviceInfo: {
      logicalCores: navigator.hardwareConcurrency || 4,
      platform: navigator.platform || 'Unknown',
      userAgent: navigator.userAgent,
      memoryEstimate,
    },
  };
}
