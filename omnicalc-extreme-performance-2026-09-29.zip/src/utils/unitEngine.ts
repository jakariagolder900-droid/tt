import { UnitCategory } from '../types';

export const UNIT_CATEGORIES: UnitCategory[] = [
  {
    id: 'length',
    name: 'Length & Distance',
    iconName: 'Ruler',
    baseUnit: 'm',
    units: [
      { id: 'm', name: 'Meters', symbol: 'm', ratioToBase: 1 },
      { id: 'km', name: 'Kilometers', symbol: 'km', ratioToBase: 1000 },
      { id: 'cm', name: 'Centimeters', symbol: 'cm', ratioToBase: 0.01 },
      { id: 'mm', name: 'Millimeters', symbol: 'mm', ratioToBase: 0.001 },
      { id: 'um', name: 'Micrometers', symbol: 'µm', ratioToBase: 1e-6 },
      { id: 'nm', name: 'Nanometers', symbol: 'nm', ratioToBase: 1e-9 },
      { id: 'mi', name: 'Miles', symbol: 'mi', ratioToBase: 1609.344 },
      { id: 'yd', name: 'Yards', symbol: 'yd', ratioToBase: 0.9144 },
      { id: 'ft', name: 'Feet', symbol: 'ft', ratioToBase: 0.3048 },
      { id: 'in', name: 'Inches', symbol: 'in', ratioToBase: 0.0254 },
      { id: 'nmi', name: 'Nautical Miles', symbol: 'NM', ratioToBase: 1852 },
      { id: 'ly', name: 'Light Years', symbol: 'ly', ratioToBase: 9.4607e15 },
    ],
  },
  {
    id: 'mass',
    name: 'Mass & Weight',
    iconName: 'Scale',
    baseUnit: 'kg',
    units: [
      { id: 'kg', name: 'Kilograms', symbol: 'kg', ratioToBase: 1 },
      { id: 'g', name: 'Grams', symbol: 'g', ratioToBase: 0.001 },
      { id: 'mg', name: 'Milligrams', symbol: 'mg', ratioToBase: 1e-6 },
      { id: 'lb', name: 'Pounds', symbol: 'lb', ratioToBase: 0.45359237 },
      { id: 'oz', name: 'Ounces', symbol: 'oz', ratioToBase: 0.02834952 },
      { id: 't', name: 'Metric Tonnes', symbol: 't', ratioToBase: 1000 },
      { id: 'ct', name: 'Carats', symbol: 'ct', ratioToBase: 0.0002 },
      { id: 'st', name: 'Stones', symbol: 'st', ratioToBase: 6.35029 },
    ],
  },
  {
    id: 'temperature',
    name: 'Temperature',
    iconName: 'Thermometer',
    baseUnit: 'C',
    units: [
      { id: 'C', name: 'Celsius', symbol: '°C', ratioToBase: 1, offset: 0 },
      { id: 'F', name: 'Fahrenheit', symbol: '°F', ratioToBase: 5 / 9, offset: 32 },
      { id: 'K', name: 'Kelvin', symbol: 'K', ratioToBase: 1, offset: 273.15 },
    ],
  },
  {
    id: 'speed',
    name: 'Speed & Velocity',
    iconName: 'Gauge',
    baseUnit: 'mps',
    units: [
      { id: 'mps', name: 'Meters per second', symbol: 'm/s', ratioToBase: 1 },
      { id: 'kmh', name: 'Kilometers per hour', symbol: 'km/h', ratioToBase: 1 / 3.6 },
      { id: 'mph', name: 'Miles per hour', symbol: 'mph', ratioToBase: 0.44704 },
      { id: 'knot', name: 'Knots', symbol: 'kn', ratioToBase: 0.514444 },
      { id: 'fps', name: 'Feet per second', symbol: 'ft/s', ratioToBase: 0.3048 },
      { id: 'mach', name: 'Mach (at sea level)', symbol: 'Ma', ratioToBase: 340.29 },
      { id: 'c', name: 'Speed of Light', symbol: 'c', ratioToBase: 299792458 },
    ],
  },
  {
    id: 'digital',
    name: 'Digital Data & Memory',
    iconName: 'HardDrive',
    baseUnit: 'byte',
    units: [
      { id: 'bit', name: 'Bits', symbol: 'b', ratioToBase: 0.125 },
      { id: 'byte', name: 'Bytes', symbol: 'B', ratioToBase: 1 },
      { id: 'kb', name: 'Kilobytes (1000B)', symbol: 'KB', ratioToBase: 1000 },
      { id: 'kib', name: 'Kibibytes (1024B)', symbol: 'KiB', ratioToBase: 1024 },
      { id: 'mb', name: 'Megabytes (1000KB)', symbol: 'MB', ratioToBase: 1e6 },
      { id: 'mib', name: 'Mebibytes (1024KiB)', symbol: 'MiB', ratioToBase: 1048576 },
      { id: 'gb', name: 'Gigabytes (1000MB)', symbol: 'GB', ratioToBase: 1e9 },
      { id: 'gib', name: 'Gibibytes (1024MiB)', symbol: 'GiB', ratioToBase: 1073741824 },
      { id: 'tb', name: 'Terabytes (1000GB)', symbol: 'TB', ratioToBase: 1e12 },
      { id: 'tib', name: 'Tebibytes (1024GiB)', symbol: 'TiB', ratioToBase: 1099511627776 },
    ],
  },
  {
    id: 'energy',
    name: 'Energy & Work',
    iconName: 'Zap',
    baseUnit: 'J',
    units: [
      { id: 'J', name: 'Joules', symbol: 'J', ratioToBase: 1 },
      { id: 'kJ', name: 'Kilojoules', symbol: 'kJ', ratioToBase: 1000 },
      { id: 'cal', name: 'Gram Calories', symbol: 'cal', ratioToBase: 4.184 },
      { id: 'kcal', name: 'Food Kilocalories', symbol: 'kcal', ratioToBase: 4184 },
      { id: 'Wh', name: 'Watt-Hours', symbol: 'Wh', ratioToBase: 3600 },
      { id: 'kWh', name: 'Kilowatt-Hours', symbol: 'kWh', ratioToBase: 3600000 },
      { id: 'eV', name: 'Electronvolts', symbol: 'eV', ratioToBase: 1.602176634e-19 },
      { id: 'BTU', name: 'British Thermal Units', symbol: 'BTU', ratioToBase: 1055.06 },
    ],
  },
  {
    id: 'pressure',
    name: 'Pressure',
    iconName: 'Compass',
    baseUnit: 'Pa',
    units: [
      { id: 'Pa', name: 'Pascals', symbol: 'Pa', ratioToBase: 1 },
      { id: 'kPa', name: 'Kilopascals', symbol: 'kPa', ratioToBase: 1000 },
      { id: 'bar', name: 'Bar', symbol: 'bar', ratioToBase: 100000 },
      { id: 'psi', name: 'Pounds per sq inch', symbol: 'psi', ratioToBase: 6894.757 },
      { id: 'atm', name: 'Standard Atmospheres', symbol: 'atm', ratioToBase: 101325 },
      { id: 'torr', name: 'Torr / mmHg', symbol: 'mmHg', ratioToBase: 133.322 },
    ],
  },
  {
    id: 'area',
    name: 'Area',
    iconName: 'Square',
    baseUnit: 'sqm',
    units: [
      { id: 'sqm', name: 'Square Meters', symbol: 'm²', ratioToBase: 1 },
      { id: 'sqkm', name: 'Square Kilometers', symbol: 'km²', ratioToBase: 1e6 },
      { id: 'sqft', name: 'Square Feet', symbol: 'ft²', ratioToBase: 0.092903 },
      { id: 'acre', name: 'Acres', symbol: 'ac', ratioToBase: 4046.86 },
      { id: 'ha', name: 'Hectares', symbol: 'ha', ratioToBase: 10000 },
      { id: 'sqmi', name: 'Square Miles', symbol: 'mi²', ratioToBase: 2.58999e6 },
    ],
  },
  {
    id: 'volume',
    name: 'Volume & Capacity',
    iconName: 'Box',
    baseUnit: 'L',
    units: [
      { id: 'L', name: 'Liters', symbol: 'L', ratioToBase: 1 },
      { id: 'mL', name: 'Milliliters', symbol: 'mL', ratioToBase: 0.001 },
      { id: 'cum', name: 'Cubic Meters', symbol: 'm³', ratioToBase: 1000 },
      { id: 'gal_us', name: 'US Gallons', symbol: 'gal', ratioToBase: 3.78541 },
      { id: 'qt_us', name: 'US Quarts', symbol: 'qt', ratioToBase: 0.946353 },
      { id: 'pt_us', name: 'US Pints', symbol: 'pt', ratioToBase: 0.473176 },
      { id: 'cup', name: 'US Cups', symbol: 'cup', ratioToBase: 0.236588 },
      { id: 'fl_oz', name: 'US Fluid Ounces', symbol: 'fl oz', ratioToBase: 0.0295735 },
    ],
  },
];

export function convertUnits(
  value: number,
  fromUnitId: string,
  toUnitId: string,
  categoryId: string
): number {
  const category = UNIT_CATEGORIES.find(c => c.id === categoryId);
  if (!category) return value;

  const fromUnit = category.units.find(u => u.id === fromUnitId);
  const toUnit = category.units.find(u => u.id === toUnitId);
  if (!fromUnit || !toUnit) return value;

  // Temperature special case
  if (categoryId === 'temperature') {
    let celsius = value;
    if (fromUnitId === 'F') {
      celsius = (value - 32) * (5 / 9);
    } else if (fromUnitId === 'K') {
      celsius = value - 273.15;
    }

    if (toUnitId === 'C') return celsius;
    if (toUnitId === 'F') return celsius * (9 / 5) + 32;
    if (toUnitId === 'K') return celsius + 273.15;
    return celsius;
  }

  // Standard ratio-to-base conversion:
  const baseValue = value * fromUnit.ratioToBase;
  return baseValue / toUnit.ratioToBase;
}
