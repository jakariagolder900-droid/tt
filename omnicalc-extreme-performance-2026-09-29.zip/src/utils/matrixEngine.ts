export type Matrix = number[][];

export function createMatrix(rows: number, cols: number, fill = 0): Matrix {
  return Array.from({ length: rows }, () => Array(cols).fill(fill));
}

export function matrixAdd(A: Matrix, B: Matrix): Matrix {
  if (A.length !== B.length || A[0].length !== B[0].length) {
    throw new Error('Matrix dimensions must match for addition');
  }
  return A.map((row, i) => row.map((val, j) => val + B[i][j]));
}

export function matrixSub(A: Matrix, B: Matrix): Matrix {
  if (A.length !== B.length || A[0].length !== B[0].length) {
    throw new Error('Matrix dimensions must match for subtraction');
  }
  return A.map((row, i) => row.map((val, j) => val - B[i][j]));
}

export function matrixMultiply(A: Matrix, B: Matrix): Matrix {
  const rA = A.length;
  const cA = A[0].length;
  const rB = B.length;
  const cB = B[0].length;

  if (cA !== rB) {
    throw new Error(`Matrix multiplication dimension mismatch: (${rA}×${cA}) and (${rB}×${cB})`);
  }

  const result = createMatrix(rA, cB, 0);
  for (let i = 0; i < rA; i++) {
    for (let k = 0; k < cA; k++) {
      const aik = A[i][k];
      for (let j = 0; j < cB; j++) {
        result[i][j] += aik * B[k][j];
      }
    }
  }
  return result;
}

export function matrixScale(A: Matrix, scalar: number): Matrix {
  return A.map(row => row.map(v => v * scalar));
}

export function matrixTranspose(A: Matrix): Matrix {
  const rows = A.length;
  const cols = A[0].length;
  const result = createMatrix(cols, rows);
  for (let i = 0; i < rows; i++) {
    for (let j = 0; j < cols; j++) {
      result[j][i] = A[i][j];
    }
  }
  return result;
}

export function matrixDeterminant(M: Matrix): number {
  const n = M.length;
  if (n !== M[0].length) throw new Error('Determinant requires square matrix');

  if (n === 1) return M[0][0];
  if (n === 2) return M[0][0] * M[1][1] - M[0][1] * M[1][0];
  if (n === 3) {
    return (
      M[0][0] * (M[1][1] * M[2][2] - M[1][2] * M[2][1]) -
      M[0][1] * (M[1][0] * M[2][2] - M[1][2] * M[2][0]) +
      M[0][2] * (M[1][0] * M[2][1] - M[1][1] * M[2][0])
    );
  }

  // Gaussian elimination with row pivoting for n >= 4
  const A = M.map(row => [...row]);
  let det = 1;

  for (let i = 0; i < n; i++) {
    let pivot = i;
    for (let j = i + 1; j < n; j++) {
      if (Math.abs(A[j][i]) > Math.abs(A[pivot][i])) {
        pivot = j;
      }
    }

    if (Math.abs(A[pivot][i]) < 1e-12) return 0;

    if (pivot !== i) {
      [A[i], A[pivot]] = [A[pivot], A[i]];
      det = -det;
    }

    det *= A[i][i];

    for (let j = i + 1; j < n; j++) {
      const factor = A[j][i] / A[i][i];
      for (let k = i + 1; k < n; k++) {
        A[j][k] -= factor * A[i][k];
      }
    }
  }

  return det;
}

export function matrixInverse(M: Matrix): Matrix {
  const n = M.length;
  if (n !== M[0].length) throw new Error('Inversion requires square matrix');

  const det = matrixDeterminant(M);
  if (Math.abs(det) < 1e-12) throw new Error('Matrix is singular (determinant = 0), inverse does not exist');

  // Augmented matrix [A | I]
  const aug: number[][] = M.map((row, i) => {
    const identityRow = Array(n).fill(0);
    identityRow[i] = 1;
    return [...row, ...identityRow];
  });

  for (let i = 0; i < n; i++) {
    let pivot = i;
    for (let j = i + 1; j < n; j++) {
      if (Math.abs(aug[j][i]) > Math.abs(aug[pivot][i])) {
        pivot = j;
      }
    }

    if (pivot !== i) {
      [aug[i], aug[pivot]] = [aug[pivot], aug[i]];
    }

    const diag = aug[i][i];
    for (let j = 0; j < 2 * n; j++) {
      aug[i][j] /= diag;
    }

    for (let j = 0; j < n; j++) {
      if (j !== i) {
        const factor = aug[j][i];
        for (let k = 0; k < 2 * n; k++) {
          aug[j][k] -= factor * aug[i][k];
        }
      }
    }
  }

  return aug.map(row => row.slice(n));
}

export function matrixTrace(M: Matrix): number {
  if (M.length !== M[0].length) throw new Error('Trace requires square matrix');
  let tr = 0;
  for (let i = 0; i < M.length; i++) {
    tr += M[i][i];
  }
  return tr;
}
