import { AngleMode, NumberFormat } from '../types';

export interface EvalContext {
  angleMode?: AngleMode;
  variables?: Record<string, number>;
}

export const CONSTANTS: Record<string, { value: number; symbol: string; desc: string }> = {
  pi: { value: Math.PI, symbol: 'π', desc: 'Archimedes constant (3.14159...)' },
  e: { value: Math.E, symbol: 'e', desc: "Euler's number (2.71828...)" },
  phi: { value: (1 + Math.sqrt(5)) / 2, symbol: 'φ', desc: 'Golden ratio (1.61803...)' },
  c: { value: 299792458, symbol: 'c', desc: 'Speed of light (2.9979e8 m/s)' },
  h: { value: 6.62607015e-34, symbol: 'h', desc: 'Planck constant (6.626e-34 J·s)' },
  G: { value: 6.6743e-11, symbol: 'G', desc: 'Gravitational constant' },
  kB: { value: 1.380649e-23, symbol: 'kB', desc: 'Boltzmann constant (J/K)' },
  Na: { value: 6.02214076e23, symbol: 'Na', desc: 'Avogadro constant (/mol)' },
};

function factorial(n: number): number {
  if (n < 0 || !Number.isInteger(n)) throw new Error('Factorial requires non-negative integer');
  if (n > 170) return Infinity;
  let res = 1;
  for (let i = 2; i <= n; i++) res *= i;
  return res;
}

function gcd(a: number, b: number): number {
  a = Math.abs(Math.round(a));
  b = Math.abs(Math.round(b));
  while (b) {
    const t = b;
    b = a % b;
    a = t;
  }
  return a;
}

function lcm(a: number, b: number): number {
  if (a === 0 || b === 0) return 0;
  return Math.abs(Math.round(a * b)) / gcd(a, b);
}

function nCr(n: number, r: number): number {
  if (r < 0 || r > n) return 0;
  if (r === 0 || r === n) return 1;
  r = Math.min(r, n - r);
  let num = 1;
  let den = 1;
  for (let i = 1; i <= r; i++) {
    num *= n - i + 1;
    den *= i;
  }
  return Math.round(num / den);
}

function nPr(n: number, r: number): number {
  if (r < 0 || r > n) return 0;
  let res = 1;
  for (let i = 0; i < r; i++) {
    res *= n - i;
  }
  return res;
}

const FUNCTIONS: Record<string, { arity: number; fn: (args: number[], mode: AngleMode) => number }> = {
  sin: {
    arity: 1,
    fn: ([x], mode) => {
      const rad = mode === 'DEG' ? (x * Math.PI) / 180 : mode === 'GRAD' ? (x * Math.PI) / 200 : x;
      // Clean up floating point near 0
      const s = Math.sin(rad);
      return Math.abs(s) < 1e-15 ? 0 : s;
    },
  },
  cos: {
    arity: 1,
    fn: ([x], mode) => {
      const rad = mode === 'DEG' ? (x * Math.PI) / 180 : mode === 'GRAD' ? (x * Math.PI) / 200 : x;
      const c = Math.cos(rad);
      return Math.abs(c) < 1e-15 ? 0 : c;
    },
  },
  tan: {
    arity: 1,
    fn: ([x], mode) => {
      const rad = mode === 'DEG' ? (x * Math.PI) / 180 : mode === 'GRAD' ? (x * Math.PI) / 200 : x;
      const cosVal = Math.cos(rad);
      if (Math.abs(cosVal) < 1e-15) throw new Error('tan undefined (division by zero)');
      const t = Math.tan(rad);
      return Math.abs(t) < 1e-15 ? 0 : t;
    },
  },
  asin: {
    arity: 1,
    fn: ([x], mode) => {
      if (x < -1 || x > 1) throw new Error('Domain error: asin argument must be between -1 and 1');
      const rad = Math.asin(x);
      return mode === 'DEG' ? (rad * 180) / Math.PI : mode === 'GRAD' ? (rad * 200) / Math.PI : rad;
    },
  },
  acos: {
    arity: 1,
    fn: ([x], mode) => {
      if (x < -1 || x > 1) throw new Error('Domain error: acos argument must be between -1 and 1');
      const rad = Math.acos(x);
      return mode === 'DEG' ? (rad * 180) / Math.PI : mode === 'GRAD' ? (rad * 200) / Math.PI : rad;
    },
  },
  atan: {
    arity: 1,
    fn: ([x], mode) => {
      const rad = Math.atan(x);
      return mode === 'DEG' ? (rad * 180) / Math.PI : mode === 'GRAD' ? (rad * 200) / Math.PI : rad;
    },
  },
  sinh: { arity: 1, fn: ([x]) => Math.sinh(x) },
  cosh: { arity: 1, fn: ([x]) => Math.cosh(x) },
  tanh: { arity: 1, fn: ([x]) => Math.tanh(x) },
  log: {
    arity: 1,
    fn: ([x]) => {
      if (x <= 0) throw new Error('Domain error: log(x) requires x > 0');
      return Math.log10(x);
    },
  },
  ln: {
    arity: 1,
    fn: ([x]) => {
      if (x <= 0) throw new Error('Domain error: ln(x) requires x > 0');
      return Math.log(x);
    },
  },
  log2: {
    arity: 1,
    fn: ([x]) => {
      if (x <= 0) throw new Error('Domain error: log2(x) requires x > 0');
      return Math.log2(x);
    },
  },
  sqrt: {
    arity: 1,
    fn: ([x]) => {
      if (x < 0) throw new Error('Domain error: sqrt requires non-negative value');
      return Math.sqrt(x);
    },
  },
  cbrt: { arity: 1, fn: ([x]) => Math.cbrt(x) },
  abs: { arity: 1, fn: ([x]) => Math.abs(x) },
  floor: { arity: 1, fn: ([x]) => Math.floor(x) },
  ceil: { arity: 1, fn: ([x]) => Math.ceil(x) },
  round: { arity: 1, fn: ([x]) => Math.round(x) },
  exp: { arity: 1, fn: ([x]) => Math.exp(x) },
  nCr: { arity: 2, fn: ([n, r]) => nCr(n, r) },
  nPr: { arity: 2, fn: ([n, r]) => nPr(n, r) },
  gcd: { arity: 2, fn: ([a, b]) => gcd(a, b) },
  lcm: { arity: 2, fn: ([a, b]) => lcm(a, b) },
};

type TokenType = 'NUMBER' | 'IDENTIFIER' | 'OPERATOR' | 'LPAREN' | 'RPAREN' | 'COMMA' | 'POSTFIX_OP';

interface Token {
  type: TokenType;
  value: string;
}

export function tokenize(expr: string): Token[] {
  // Normalize symbols
  const cleaned = expr
    .replace(/×/g, '*')
    .replace(/÷/g, '/')
    .replace(/−/g, '-')
    .replace(/π/g, 'pi')
    .replace(/φ/g, 'phi')
    .replace(/\s+/g, '');

  const tokens: Token[] = [];
  let i = 0;

  while (i < cleaned.length) {
    const ch = cleaned[i];

    // Numbers (including decimals and scientific notation like 1e5)
    if (/[0-9]/.test(ch) || (ch === '.' && i + 1 < cleaned.length && /[0-9]/.test(cleaned[i + 1]))) {
      let numStr = '';
      while (i < cleaned.length && (/[0-9.]/.test(cleaned[i]) || (cleaned[i].toLowerCase() === 'e' && /[0-9+-]/.test(cleaned[i + 1] || '')))) {
        if (cleaned[i].toLowerCase() === 'e') {
          numStr += cleaned[i];
          i++;
          if (cleaned[i] === '+' || cleaned[i] === '-') {
            numStr += cleaned[i];
            i++;
          }
        } else {
          numStr += cleaned[i];
          i++;
        }
      }
      tokens.push({ type: 'NUMBER', value: numStr });
      continue;
    }

    // Identifiers (functions, constants, variables)
    if (/[a-zA-Z_]/.test(ch)) {
      let ident = '';
      while (i < cleaned.length && /[a-zA-Z0-9_]/.test(cleaned[i])) {
        ident += cleaned[i];
        i++;
      }
      tokens.push({ type: 'IDENTIFIER', value: ident });
      continue;
    }

    // Parentheses
    if (ch === '(') {
      tokens.push({ type: 'LPAREN', value: '(' });
      i++;
      continue;
    }
    if (ch === ')') {
      tokens.push({ type: 'RPAREN', value: ')' });
      i++;
      continue;
    }

    // Comma
    if (ch === ',') {
      tokens.push({ type: 'COMMA', value: ',' });
      i++;
      continue;
    }

    // Postfix operator: Factorial '!' or percentage '%'
    if (ch === '!') {
      tokens.push({ type: 'POSTFIX_OP', value: '!' });
      i++;
      continue;
    }

    // Operators
    if (['+', '-', '*', '/', '^', '%'].includes(ch)) {
      tokens.push({ type: 'OPERATOR', value: ch });
      i++;
      continue;
    }

    throw new Error(`Unexpected character: "${ch}"`);
  }

  // Insert implicit multiplication: e.g. 2pi -> 2*pi, 2(3) -> 2*(3), (2)(3) -> (2)*(3), x(y) -> x*y
  const expanded: Token[] = [];
  for (let j = 0; j < tokens.length; j++) {
    const curr = tokens[j];
    const prev = tokens[j - 1];

    if (prev) {
      const prevCanMultiply =
        prev.type === 'NUMBER' ||
        prev.type === 'RPAREN' ||
        prev.type === 'POSTFIX_OP' ||
        (prev.type === 'IDENTIFIER' && !FUNCTIONS[prev.value]);

      const currCanMultiply =
        curr.type === 'NUMBER' ||
        curr.type === 'LPAREN' ||
        (curr.type === 'IDENTIFIER' && !FUNCTIONS[curr.value]) ||
        (curr.type === 'IDENTIFIER' && FUNCTIONS[curr.value]);

      if (prevCanMultiply && currCanMultiply) {
        expanded.push({ type: 'OPERATOR', value: '*' });
      }
    }

    expanded.push(curr);
  }

  return expanded;
}

const PRECEDENCE: Record<string, number> = {
  '+': 1,
  '-': 1,
  '*': 2,
  '/': 2,
  '%': 2,
  'u-': 3, // unary minus
  '^': 4,
};

const RIGHT_ASSOCIATIVE: Record<string, boolean> = {
  '^': true,
  'u-': true,
};

export function evaluateExpression(expr: string, context: EvalContext = {}): number {
  if (!expr || !expr.trim()) return 0;
  const tokens = tokenize(expr);
  if (tokens.length === 0) return 0;

  const mode = context.angleMode || 'RAD';
  const vars = context.variables || {};

  // Convert to RPN via Shunting-Yard
  const outputQueue: Array<{ type: string; value: string; arity?: number }> = [];
  const opStack: Array<{ type: string; value: string; arity?: number }> = [];

  for (let i = 0; i < tokens.length; i++) {
    const token = tokens[i];
    const prev = tokens[i - 1];

    if (token.type === 'NUMBER') {
      outputQueue.push({ type: 'NUMBER', value: token.value });
    } else if (token.type === 'IDENTIFIER') {
      if (FUNCTIONS[token.value]) {
        opStack.push({ type: 'FUNCTION', value: token.value, arity: FUNCTIONS[token.value].arity });
      } else if (CONSTANTS[token.value.toLowerCase()]) {
        outputQueue.push({ type: 'CONSTANT', value: token.value.toLowerCase() });
      } else if (token.value in vars) {
        outputQueue.push({ type: 'VARIABLE', value: token.value });
      } else {
        throw new Error(`Unknown variable or function: "${token.value}"`);
      }
    } else if (token.type === 'COMMA') {
      while (opStack.length > 0 && opStack[opStack.length - 1].value !== '(') {
        outputQueue.push(opStack.pop()!);
      }
      if (opStack.length === 0) {
        throw new Error('Misplaced comma or mismatched parentheses');
      }
    } else if (token.type === 'POSTFIX_OP') {
      outputQueue.push({ type: 'POSTFIX_OP', value: token.value });
    } else if (token.type === 'OPERATOR') {
      // Check for unary minus
      let op = token.value;
      if (op === '-' && (!prev || prev.type === 'OPERATOR' || prev.type === 'LPAREN' || prev.type === 'COMMA')) {
        op = 'u-';
      }

      while (
        opStack.length > 0 &&
        opStack[opStack.length - 1].value !== '(' &&
        (opStack[opStack.length - 1].type === 'FUNCTION' ||
          PRECEDENCE[opStack[opStack.length - 1].value] > PRECEDENCE[op] ||
          (PRECEDENCE[opStack[opStack.length - 1].value] === PRECEDENCE[op] && !RIGHT_ASSOCIATIVE[op]))
      ) {
        outputQueue.push(opStack.pop()!);
      }
      opStack.push({ type: 'OPERATOR', value: op });
    } else if (token.type === 'LPAREN') {
      opStack.push({ type: 'LPAREN', value: '(' });
    } else if (token.type === 'RPAREN') {
      while (opStack.length > 0 && opStack[opStack.length - 1].value !== '(') {
        outputQueue.push(opStack.pop()!);
      }
      if (opStack.length === 0) {
        throw new Error('Mismatched parentheses: unexpected ")"');
      }
      opStack.pop(); // Pop '('

      // If function is on top of opStack, pop it into outputQueue
      if (opStack.length > 0 && opStack[opStack.length - 1].type === 'FUNCTION') {
        outputQueue.push(opStack.pop()!);
      }
    }
  }

  while (opStack.length > 0) {
    const top = opStack.pop()!;
    if (top.value === '(' || top.value === ')') {
      throw new Error('Mismatched parentheses in expression');
    }
    outputQueue.push(top);
  }

  // RPN Evaluation
  const evalStack: number[] = [];

  for (const item of outputQueue) {
    if (item.type === 'NUMBER') {
      evalStack.push(parseFloat(item.value));
    } else if (item.type === 'CONSTANT') {
      evalStack.push(CONSTANTS[item.value].value);
    } else if (item.type === 'VARIABLE') {
      evalStack.push(vars[item.value] ?? 0);
    } else if (item.type === 'POSTFIX_OP') {
      if (evalStack.length < 1) throw new Error('Missing operand for factorial');
      const val = evalStack.pop()!;
      evalStack.push(factorial(val));
    } else if (item.type === 'FUNCTION') {
      const fnDef = FUNCTIONS[item.value];
      if (!fnDef) throw new Error(`Unknown function: ${item.value}`);
      if (evalStack.length < fnDef.arity) throw new Error(`Insufficient arguments for ${item.value}`);
      const args: number[] = [];
      for (let i = 0; i < fnDef.arity; i++) {
        args.unshift(evalStack.pop()!);
      }
      const res = fnDef.fn(args, mode);
      evalStack.push(res);
    } else if (item.type === 'OPERATOR') {
      if (item.value === 'u-') {
        if (evalStack.length < 1) throw new Error('Missing operand for unary minus');
        const v = evalStack.pop()!;
        evalStack.push(-v);
      } else {
        if (evalStack.length < 2) throw new Error(`Missing operands for operator ${item.value}`);
        const b = evalStack.pop()!;
        const a = evalStack.pop()!;

        switch (item.value) {
          case '+':
            evalStack.push(a + b);
            break;
          case '-':
            evalStack.push(a - b);
            break;
          case '*':
            evalStack.push(a * b);
            break;
          case '/':
            if (b === 0) throw new Error('Division by zero');
            evalStack.push(a / b);
            break;
          case '%':
            evalStack.push(a % b);
            break;
          case '^':
            evalStack.push(Math.pow(a, b));
            break;
          default:
            throw new Error(`Unsupported operator: ${item.value}`);
        }
      }
    }
  }

  if (evalStack.length !== 1) {
    throw new Error('Invalid syntax: incomplete evaluation');
  }

  return evalStack[0];
}

// Convert decimal to exact or approximate fraction string
export function toFraction(val: number, tolerance = 1e-6): string | null {
  if (!Number.isFinite(val)) return null;
  if (Number.isInteger(val)) return null;

  let h1 = 1, h2 = 0;
  let k1 = 0, k2 = 1;
  let b = Math.abs(val);

  do {
    const a = Math.floor(b);
    let aux = h1;
    h1 = a * h1 + h2;
    h2 = aux;
    aux = k1;
    k1 = a * k1 + k2;
    k2 = aux;
    b = 1 / (b - a);
  } while (Math.abs(Math.abs(val) - h1 / k1) > Math.abs(val) * tolerance && k1 < 10000);

  if (k1 === 1 || k1 > 10000) return null;
  const sign = val < 0 ? '-' : '';
  return `${sign}${h1}/${k1}`;
}

export function formatResult(value: number, format: NumberFormat = 'standard', precision = 10): string {
  if (Number.isNaN(value)) return 'NaN';
  if (!Number.isFinite(value)) return value > 0 ? 'Infinity' : '-Infinity';

  // Fix floating point epsilon errors like 0.1 + 0.2 = 0.30000000000000004
  const rounded = Number(Math.round(Number(value + 'e' + precision)) + 'e-' + precision);

  switch (format) {
    case 'scientific':
      return value.toExponential(6);
    case 'engineering': {
      if (value === 0) return '0';
      const exp = Math.floor(Math.log10(Math.abs(value)));
      const engExp = Math.floor(exp / 3) * 3;
      const engVal = value / Math.pow(10, engExp);
      return `${engVal.toFixed(4)}e${engExp >= 0 ? '+' : ''}${engExp}`;
    }
    case 'fraction': {
      const frac = toFraction(value);
      if (frac) return `${frac} (${rounded})`;
      return rounded.toString();
    }
    case 'standard':
    default: {
      if (Math.abs(value) > 1e14 || (Math.abs(value) < 1e-7 && value !== 0)) {
        return value.toPrecision(8);
      }
      return rounded.toLocaleString('en-US', {
        maximumFractionDigits: precision,
        useGrouping: false,
      });
    }
  }
}
